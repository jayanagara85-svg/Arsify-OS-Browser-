# Testing Guide — Upshalter Workspace v2

## Test Pyramid

```
Layer 4  smoke/         3 real briefs · real LLM · score ≥ 70 · runtime < 3 min
Layer 3  integration/   full marshal.run() · mocked LLM · retry loop · session state
Layer 2  unit/          EntityExtractor · PrdValidator · scoring · contracts
Layer 1  (in unit/)     ContextBundle frozen · agent protocol · import boundaries
```

---

## When to Run What

| Event | Command | Time | Cost |
|-------|---------|------|------|
| Editing a prompt file | `make test-unit` | ~5s | $0 |
| Editing Marshal/Agent code | `make test` | ~15s | $0 |
| Before git push | `make test` | ~15s | $0 |
| Before deploy to Sumopod | `make test-smoke` | ~3 min | ~$0.45 |
| After deploy | `make smoke-criteria` | ~1 min | ~$0.15 |

---

## Layer 1 — Contract Tests (`tests/unit/test_contract.py`)

**What they prove:**
- `ContextBundle` is frozen — agents cannot modify the context they receive
- `EntityManifest` is frozen
- `DocumentAgent` protocol is enforced — non-conforming agents rejected at startup
- `main.py` does not import agent classes directly

**Run with:** `make test-unit`  
**Expected output:** All green in ~2 seconds.

---

## Layer 2 — Unit Tests

### `test_prd_validator.py`
Verifies the structural checker catches missing Glossary, missing Features, and short acceptance criteria.

### `test_entity_extractor.py`
Verifies the regex path extracts canonical names from the sample PRD correctly.
Uses `VALID_PRD` from `fixtures/sample_prd.py` — no LLM call needed.

### `test_consistency_scoring.py`
Verifies the scoring formula: `100 - (15 × critical) - (5 × warning)`.  
Verifies `consistent = (critical_count == 0)`.  
These tests directly verify the Phase 1.5 success criterion: "PRD + SDD + API consistent."

**Run with:** `make test-unit`  
**Expected output:** 25+ tests, all green, ~5 seconds total.

---

## Layer 3 — Integration Tests (`tests/integration/`)

**What they prove:**
- `MarshalV1.run()` completes the full pipeline with mocked LLM responses
- Session state transitions: QUEUED → GENERATING_PRD → ... → COMPLETE
- All 3 output files written to the session directory
- Retry loop: critical conflict on attempt 0 → retry → clean on attempt 1
- Max retries: still completes with score < 100 when all attempts fail
- `PipelineRequest` validation rejects short briefs

**How the mock works:**  
`MockAsyncClient` replaces `httpx.AsyncClient`. It returns pre-built responses in sequence.
The sequence maps to the order of LLM calls: PRD → SDD → API → Consistency.

**Run with:** `make test-integration`  
**Expected output:** 15+ tests, all green, ~10 seconds total.

---

## Layer 4 — Smoke Tests (`tests/smoke/`)

**Requires:** A running or_gateway on Sumopod.

```bash
export PIPELINE_LLM_GATEWAY=http://SUMOPOD_IP:4000
make test-smoke
```

**What they prove:**
- Real LLM calls produce substantive output (≥ 500 chars per document)
- Consistency score ≥ 70 for all 3 canonical briefs
- API spec is valid YAML with `openapi`, `paths`, `components` keys
- Pipeline completes in < 3 minutes
- `test_three_brief_aggregate` — the single Phase 1.5 success criterion test

**Three canonical briefs:**
- `BRIEF_SAAS` — project management (Workspace, Member, Project, Task, AuditLog)
- `BRIEF_MARKETPLACE` — peer-to-peer marketplace (Item, Offer, Transaction, Review)
- `BRIEF_API_PRODUCT` — document parsing API (Document, ParseJob, Clause, ApiKey)

**Expected runtime:** ~90–150 seconds total for all three briefs.  
**Expected cost:** ~$0.30–0.50 USD at claude-sonnet-4-6 pricing.

---

## Interpreting Smoke Test Failures

| Failure | Cause | Fix |
|---------|-------|-----|
| Score < 70 | Entity drift in Architect Agent | Improve `architect_sdd.txt` prompt |
| API spec invalid YAML | Architect hallucinated code fences | Improve `architect_api.txt` stripping logic |
| PRD missing Glossary | Product Agent missed the section | Improve `product_prd.txt` template enforcement |
| Pipeline timeout | LLM latency or fallback firing | Check or_gateway logs, LiteLLM fallback chain |
| ConsistencyEngine parse error | JSON response malformed | Review `consistency_check.txt` JSON instruction |

---

## Coverage Target

```bash
make coverage
```

Target: **≥ 80% line coverage** on `pipeline_engine` package.  
Critical paths (Marshal, EntityExtractor, ConsistencyEngine) should be ≥ 90%.
