"""
UPSHALTER — RESPONSIBILITY CONTRACT
Marshal Engine v1 · System Lock

This module defines the ROLE BOUNDARIES of every component in the pipeline.
It is the authoritative source on what each component can and cannot do.

Enforcement mechanism: Python Protocols + frozen Pydantic models.
Any component that violates its contract fails at the type checker or at runtime.

─────────────────────────────────────────────────────
ROLES
─────────────────────────────────────────────────────
Planner     → routes requests, creates session, launches background task
Marshal v1  → validates, extracts, decides, assembles context, manages retry
Agent       → receives context, generates document string, returns it
─────────────────────────────────────────────────────

WHAT AGENTS CANNOT DO (enforced):
  ✗ Update session state (no SessionManager reference)
  ✗ Modify ContextBundle (frozen Pydantic model)
  ✗ Call other agents (no reference to other agent instances)
  ✗ Make retry decisions (no access to ConsistencyResult)
  ✗ Choose which model to use (model is set in agent __init__)

WHAT MARSHAL CANNOT DO (by convention, enforced by code review):
  ✗ Generate document content directly (must call an agent)
  ✗ Return results without consistency check
  ✗ Allow agent output to pass to next step without validation
  ✗ Bypass the EntityManifest injection step

WHAT PLANNER CANNOT DO (enforced):
  ✗ Call agents directly (all calls go through Marshal.run())
  ✗ Read or write document files (no FileStore reference)
  ✗ Make retry decisions (no access to ConsistencyResult)
"""
from __future__ import annotations
from typing import Protocol, runtime_checkable
from pydantic import BaseModel


# ── Agent Protocol ────────────────────────────────────────────────────────────

@runtime_checkable
class DocumentAgent(Protocol):
    """
    The contract every agent MUST conform to.

    Agents are pure generators:
    - They receive a ContextBundle (immutable).
    - They produce a document string.
    - They write the string to the session directory via FileStore.
    - They return the string.
    - They do nothing else.

    Runtime check:
        assert isinstance(product_agent, DocumentAgent)  # ✓ if conforming

    Any class claiming to be an agent that does not conform to this
    protocol will be rejected at the isinstance() check in MarshalV1._execute().
    """
    async def generate(
        self,
        context: "ContextBundle",
        session_id: str,
        attempt: int,
    ) -> str:
        """Generate one document. Input: context. Output: document string."""
        ...


# ── ContextBundle (frozen — immutable after Marshal assembles it) ─────────────

# Import the actual ContextBundle to expose its frozen configuration here.
# The frozen config is defined in v1_schemas.py. Agents that attempt
# context.sdd_content = "something" will get a ValidationError at runtime.
#
# model_config = ConfigDict(frozen=True)  ← defined in v1_schemas.ContextBundle


# ── Planner Contract ──────────────────────────────────────────────────────────

class PlannerContract:
    """
    Documents what the Planner (main.py FastAPI app) is allowed to do.
    Enforced through argument types — the Planner only holds a Marshal reference,
    not references to any individual agent.
    """
    ALLOWED = [
        "receive_http_request",
        "validate_request_schema",       # via Pydantic PipelineRequest
        "call_marshal_create_session",   # marshal.create_session(brief) → session_id
        "launch_background_task",        # background_tasks.add_task(marshal.run, ...)
        "return_session_id",             # HTTP 202 response
        "read_session_status",           # marshal.session_manager.get(session_id)
        "read_session_output",           # file_store.read(session_id, filename)
    ]

    FORBIDDEN = [
        "call_product_agent_directly",   # ProductAgent must not be accessible from main.py
        "call_architect_agent_directly",
        "call_consistency_engine_directly",
        "write_session_files_directly",
        "read_consistency_result",
        "make_retry_decisions",
    ]


# ── Marshal Contract ──────────────────────────────────────────────────────────

class MarshalContract:
    """
    Documents what Marshal v1 is allowed to do.
    Marshal is the only component that touches all other components.
    """
    ALLOWED = [
        "validate_brief_length",
        "create_session",
        "update_session_status",
        "call_product_agent",
        "validate_prd_structure",
        "extract_entity_manifest",
        "assemble_context_bundle",
        "call_architect_agent_sdd",
        "call_architect_agent_api",
        "call_consistency_engine",
        "read_consistency_result",
        "decide_retry_or_accept",
        "mark_session_complete",
        "mark_session_failed",
    ]

    FORBIDDEN = [
        "generate_prd_content_directly",     # must call ProductAgent
        "generate_sdd_content_directly",     # must call ArchitectAgent
        "generate_api_spec_content_directly",
        "skip_consistency_check",            # every Architect output must be checked
        "skip_entity_extraction",            # EntityManifest must always be attempted
        "expose_session_manager_to_agents",  # agents have no SessionManager reference
    ]


# ── Agent Contract ────────────────────────────────────────────────────────────

class AgentContract:
    """
    Documents what any agent is allowed to do.
    Agents are the simplest components in the system.
    """
    ALLOWED = [
        "receive_context_bundle",            # read-only, frozen
        "read_context_bundle_fields",
        "call_llm_gateway",                  # via httpx to or_gateway
        "write_document_to_file_store",      # FileStore.write(session_id, filename, content)
        "return_document_string",
        "log_generation_progress",
    ]

    FORBIDDEN = [
        "modify_context_bundle",             # frozen — raises ValidationError
        "call_other_agents",                 # no cross-agent references
        "update_session_status",             # no SessionManager reference
        "read_consistency_result",           # not passed to agents
        "decide_to_retry",                   # Marshal's responsibility
        "choose_model_at_runtime",           # model is fixed in agent __init__
        "access_other_session_ids",          # only their own session_id
    ]


# ── Runtime Assertion Helpers ──────────────────────────────────────────────────

def assert_agent_conformance(agent: object, name: str) -> None:
    """
    Assert that an object conforms to the DocumentAgent protocol.
    Called in MarshalV1.__init__ for every agent it holds.

    Raises TypeError if the agent does not implement the protocol.
    """
    if not isinstance(agent, DocumentAgent):
        raise TypeError(
            f"{name} does not conform to DocumentAgent protocol. "
            f"It must implement: async def generate(context, session_id, attempt) -> str"
        )


def assert_context_frozen(context: BaseModel) -> None:
    """
    Assert that a context object is frozen (immutable).
    Agents call this at the start of generate() to confirm they received
    an immutable context — not a mutable dict or object.

    Usage in agents:
        from .responsibility_contract import assert_context_frozen
        assert_context_frozen(context)
    """
    config = getattr(context, 'model_config', {})
    if not config.get('frozen', False):
        raise TypeError(
            f"Context object {type(context).__name__} is not frozen. "
            "Agents must receive an immutable ContextBundle."
        )
