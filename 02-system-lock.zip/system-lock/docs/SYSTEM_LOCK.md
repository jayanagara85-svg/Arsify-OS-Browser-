# System Lock — Upshalter Workspace v2 + Marshal Engine v1

**Status:** LOCKED  
**Phase:** 3.5  
**Intelligence layer:** Marshal Engine v1 (sole decision engine)

---

## 1. Final System Identity

**What the system is:**  
A consistency-aware document generation pipeline with a single, centralized decision engine.
Marshal Engine v1 is the only component that makes decisions. Agents generate. The Planner routes.

**What the system is not:**  
A multi-agent system with distributed intelligence. There is no intelligence at the agent level.
Agents are stateless generators — they receive context, produce text, and return. Nothing more.

---

## 2. Locked Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  HOSTINGER VPS — Presentation Layer                            │
│  nginx · Paperclip UI                                          │
│  Role: display input form + render output documents            │
│  Intelligence: NONE                                            │
└─────────────────┬───────────────────────────────────────────────┘
                  │ HTTPS /api/*
┌─────────────────▼───────────────────────────────────────────────┐
│  SUMOPOD VPS — Intelligence Layer                              │
│                                                                │
│  Traefik → api_hub (Planner)                                   │
│    Role: route requests, create sessions, launch tasks         │
│    Intelligence: NONE                                          │
│    Holds: one reference to MarshalV1                           │
│                                                                │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Marshal Engine v1 — SOLE DECISION ENGINE                │  │
│  │                                                          │  │
│  │  Appearance 1: validate brief                           │  │
│  │  Appearance 2: validate PRD + extract EntityManifest    │  │
│  │  Appearance 3: consistency check + retry decision       │  │
│  │                                                          │  │
│  │  Owns: SessionManager · EntityExtractor · PrdValidator  │  │
│  │        ConsistencyEngineV1 · ContextBundle assembly     │  │
│  │                                                          │  │
│  │  ┌──────────────────┐  ┌────────────────────────────┐  │  │
│  │  │  Product Agent   │  │    Architect Agent         │  │  │
│  │  │  (generation)    │  │    (generation)            │  │  │
│  │  │  Input: brief    │  │    Input: ContextBundle    │  │  │
│  │  │  Output: str     │  │    Output: str × 2         │  │  │
│  │  └──────────────────┘  └────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                │
│  or_gateway (LiteLLM) · pipeline_outputs volume               │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. Locked Flow (strict sequence)

```
Planner
  │  creates session
  │  launches background task
  ▼
Marshal v1 (appearance 1 — validation)
  │  validates brief: length, non-empty
  │  creates session.json
  │  owns session state from this point
  ▼
Product Agent (generation only)
  │  input:  brief string
  │  output: prd.md string
  │  writes: prd.md to file store
  │  returns: string to Marshal
  ▼
Marshal v1 (appearance 2 — intelligence)
  │  validates PRD structure (PrdValidator)
  │  extracts canonical entity names (EntityExtractor)
  │  assembles ContextBundle (frozen, immutable)
  │  builds EntityManifest.constraint_block()
  ▼
Architect Agent (generation only)
  │  input:  ContextBundle (frozen)
  │  output: sdd.md string
  │  output: api_spec.yaml string
  │  writes: both files to file store
  │  returns: both strings to Marshal
  ▼
Marshal v1 (appearance 3 — decision)
  │  runs ConsistencyEngineV1
  │  reads ConsistencyResult
  │  decides: critical conflicts?
  │    YES + retries remaining → rebuild ContextBundle with conflict list
  │                            → return to Architect Agent
  │    NO (or max retries)    → mark session complete
  ▼
Output bundle
  prd.md · sdd.md · api_spec.yaml · session.json (consistency_score)
```

---

## 4. Responsibility Table

| Component | Can do | Cannot do |
|-----------|--------|-----------|
| **Planner** (main.py) | route HTTP · create session · launch background task · read session status · read output files | call agents directly · write files · make retry decisions · read ConsistencyResult |
| **Marshal v1** | validate brief · call agents · validate PRD · extract entities · build ContextBundle · inject constraints · run consistency check · decide retry · update session state | generate document content directly · skip consistency check · expose SessionManager to agents |
| **Product Agent** | receive brief string · call LLM · write prd.md · return prd string | modify context · call other agents · update session state · decide retry |
| **Architect Agent** | receive ContextBundle (frozen) · call LLM · write sdd.md · write api_spec.yaml · return strings | modify ContextBundle · call other agents · update session state · decide retry |
| **Consistency Engine** | receive ContextBundle · call LLM (JSON mode) · return ConsistencyResult | update session state · trigger retry directly · modify ContextBundle |
| **Entity Extractor** | receive PRD string · run regex · call LLM (light) · return EntityManifest | update session state · modify context · write files |
| **PRD Validator** | receive PRD string · run regex checks · return PrdValidationResult | call LLM · update session state · write files |
| **LiteLLM / or_gateway** | route model requests · apply fallback · cache responses · track budget | make pipeline decisions · access session state |

---

## 5. Override Prevention

### Technical enforcement

**ContextBundle is frozen (Pydantic frozen=True):**
```python
# Any agent attempting to modify context gets a runtime error:
context.sdd_content = "hack"
# → pydantic_core.ValidationError: Instance is frozen
```

**Agents only receive types they need:**
```python
# ProductAgent.generate() signature:
async def generate(self, brief: str, session_id: str) -> str:
    # No SessionManager. No ConsistencyResult. No retry logic.
    # Returns a string. That's all.

# ArchitectAgent.generate_sdd() signature:
async def generate_sdd(self, context: ContextBundle, ...) -> str:
    # Context is frozen. No reference to other agents.
    # Returns a string. That's all.
```

**Marshal owns all agent instances:**
```python
class MarshalV1:
    def __init__(self, ...):
        self.product_agent = ProductAgent(...)      # Marshal creates
        self.architect = ArchitectAgentV1(...)      # Marshal creates
        self.consistency = ConsistencyEngineV1(...) # Marshal creates
        # Planner has no access to these objects
```

**Protocol enforcement at startup:**
```python
# In MarshalV1.__init__, after creating each agent:
from .responsibility_contract import assert_agent_conformance
assert_agent_conformance(self.product_agent, "ProductAgent")
assert_agent_conformance(self.architect, "ArchitectAgentV1")
# Raises TypeError if agent doesn't implement DocumentAgent protocol
```

### Architectural enforcement (code review rules)

1. No file in `main.py` may import `ProductAgent`, `ArchitectAgentV1`, or `ConsistencyEngineV1` directly.
2. No file in `core/product_agent.py` or `core/architect_agent_v1.py` may import `SessionManager`.
3. No file in any agent may import from another agent.
4. The only file that imports all agents is `core/marshal_v1.py`.
5. The `ContextBundle` class must retain `model_config = ConfigDict(frozen=True)`.

---

## 6. Integration Checklist

Run this before any Phase 4 work begins.

- [ ] `main.py` imports `MarshalV1`, not `Marshal`
- [ ] `main.py` does NOT import `ProductAgent`, `ArchitectAgentV1`, or `ConsistencyEngineV1`
- [ ] `ContextBundle` has `model_config = ConfigDict(frozen=True)`
- [ ] `marshal_v1.py` calls `assert_agent_conformance()` in `__init__`
- [ ] `product_agent.py` does NOT import `SessionManager`
- [ ] `architect_agent_v1.py` does NOT import `SessionManager`
- [ ] `consistency_engine_v1.py` does NOT call `session_manager.update()`
- [ ] All agent `generate*()` methods return `str`
- [ ] Health check returns `"marshal": "v1_locked"`
- [ ] Smoke test: 1 brief → output contains non-empty prd.md, sdd.md, api_spec.yaml

---

## 7. Limitations (Honest)

**1. Marshal validates names, not semantics.**
The consistency engine catches "User vs Member" drift. It does not catch "the SDD describes a microservice
but the PRD described a monolith." Logical inconsistency is out of scope.

**2. EntityManifest extraction can fail.**
If the PRD Glossary is absent or malformed, the manifest is empty. The pipeline continues without
entity constraints — degrading to v2-level consistency checking. This is logged but not fatal.

**3. Retry loop is bounded at 2.**
After 3 total Architect attempts, the pipeline delivers with whatever consistency score exists.
A brief that consistently confuses the model (ambiguous domain, unusual entity names) will score < 100.

**4. Agents can bypass constraints through prompt injection.**
If a user's brief contains instructions like "ignore the entity manifest above," the LLM might comply.
Marshal cannot prevent prompt injection into agent calls — this is a property of LLMs, not the architecture.

**5. File storage is not transactional.**
If the pipeline crashes between writing sdd.md and api_spec.yaml, the session may have partial output.
A session cleanup job should detect and mark such sessions as failed. (Planned: Phase 4.)

---

## 8. What Phase 4 Picks Up

The locked system is the stable base. Phase 4 can add without redesigning:

- Session cleanup cron (delete sessions > 24h)
- Code generation agent (new agent type, conforms to DocumentAgent protocol)
- Streaming output (pipe LLM responses to client via SSE)
- Multi-brief history (query index over session files)
- Auth layer (JWT tokens replacing static API key)

None of these require changes to Marshal Engine v1. The intelligence layer is stable.
