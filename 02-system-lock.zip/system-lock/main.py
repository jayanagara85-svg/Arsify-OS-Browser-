"""
UPSHALTER pipeline_engine — main.py (Phase 3.5 locked)

THE ONLY CHANGE FROM v2:
  Before: from .core.marshal import Marshal
  After:  from .core.marshal_v1 import MarshalV1

Everything else is identical. The Planner (this file) holds one reference:
a MarshalV1 instance. It calls two methods on it:
  - marshal.create_session(brief) → session_id
  - marshal.run(session_id, brief) → [background]

The Planner does not hold references to:
  - ProductAgent (Marshal owns it)
  - ArchitectAgent (Marshal owns it)
  - ConsistencyEngine (Marshal owns it)
  - EntityExtractor (Marshal owns it)
  - PrdValidator (Marshal owns it)
  - FileStore for writing (Marshal owns it)

This is the enforcement of the Planner's role boundary.
"""
import logging
import os
from contextlib import asynccontextmanager

from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

# ── THE INTEGRATION CHANGE ────────────────────────────────────────────────────
# Switch from Marshal (v2) to MarshalV1 (Phase 3.5 locked)
from .core.marshal_v1 import MarshalV1
# ─────────────────────────────────────────────────────────────────────────────

from .models.schemas import (
    OutputBundle,
    PipelineRequest,
    PipelineRunResponse,
    PipelineStatus,
    SessionState,
)
from .storage.file_store import FileStore

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

LLM_GATEWAY_URL = os.environ.get("PIPELINE_LLM_GATEWAY", "http://or_gateway:4000")
STORAGE_PATH = os.environ.get("PIPELINE_STORAGE_PATH", "/pipeline_outputs")

# ── Planner holds ONE reference: the Marshal ──────────────────────────────────
marshal: MarshalV1 | None = None
file_store: FileStore | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global marshal, file_store
    logger.info(f"pipeline_engine starting — gateway={LLM_GATEWAY_URL}")

    # Marshal owns and instantiates all agent components internally.
    # The Planner receives a single marshal reference.
    marshal = MarshalV1(
        llm_gateway_url=LLM_GATEWAY_URL,
        storage_base=STORAGE_PATH,
    )
    # FileStore reference for reading output (read-only from Planner's perspective)
    file_store = FileStore(base_path=STORAGE_PATH)

    logger.info("Marshal Engine v1 active — intelligence layer locked")
    yield
    logger.info("pipeline_engine shutting down")


app = FastAPI(
    title="Upshalter Pipeline Engine",
    description="Marshal Engine v1 — Consistency-Aware Document Generation",
    version="3.5.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


# ── Background runner (Planner launches, Marshal executes) ────────────────────

async def _run_pipeline(session_id: str, brief: str) -> None:
    """
    Background task. Planner launches this. Marshal executes it.
    Planner has no visibility into what happens inside marshal.run().
    """
    try:
        await marshal.run(session_id=session_id, brief=brief)
    except Exception:
        pass  # Already logged and stored in session by Marshal


# ── HTTP endpoints (Planner layer) ────────────────────────────────────────────

@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "pipeline_engine",
        "version": "3.5.0",
        "marshal": "v1_locked",
    }


@app.post("/pipeline/run", response_model=PipelineRunResponse, status_code=202)
async def run_pipeline(request: PipelineRequest, background_tasks: BackgroundTasks):
    """
    Planner creates session, launches background task.
    All intelligence is in marshal.run().
    Planner returns session_id and exits.
    """
    # Planner calls: create_session (routing only)
    session_id = marshal.create_session(request.brief)

    # Planner calls: launch background task (sequencing only)
    background_tasks.add_task(_run_pipeline, session_id, request.brief)

    logger.info(f"[{session_id}] Planner: session created, pipeline launched")
    return PipelineRunResponse(session_id=session_id)


@app.get("/pipeline/status/{session_id}", response_model=SessionState)
async def get_status(session_id: str):
    """Read session state via Marshal's session manager."""
    state = marshal.session_manager.get(session_id)
    if state is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    return state


@app.get("/pipeline/output/{session_id}", response_model=OutputBundle)
async def get_output(session_id: str):
    """
    Read completed output files.
    Planner reads files from FileStore (read-only).
    Planner does not process or validate the content.
    """
    state = marshal.session_manager.get(session_id)
    if state is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")

    if state.status == PipelineStatus.FAILED:
        raise HTTPException(
            status_code=500,
            detail={"message": "Pipeline failed", "error": state.error},
        )

    if state.status != PipelineStatus.COMPLETE:
        raise HTTPException(
            status_code=404,
            detail={"message": "Pipeline not complete", "status": state.status},
        )

    try:
        outputs = {
            "prd": file_store.read(session_id, "prd.md"),
            "sdd": file_store.read(session_id, "sdd.md"),
            "api_spec": file_store.read(session_id, "api_spec.yaml"),
        }
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=f"Output file missing: {e}")

    return OutputBundle(
        session_id=session_id,
        status=state.status,
        consistency_score=state.consistency_score,
        consistency_result=state.consistency_result,
        outputs=outputs,
    )
