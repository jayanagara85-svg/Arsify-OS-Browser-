"""
ContextBundle — FROZEN after Marshal assembles it.

Agents receive this object. They cannot modify it.
If any agent attempts: context.sdd_content = "..."
Python raises: pydantic_core.ValidationError: Instance is frozen

This is the primary technical enforcement of the agent boundary.
Marshal creates new ContextBundle instances via model_copy(update={...})
as the pipeline progresses — agents only ever see their specific snapshot.
"""
from __future__ import annotations
from typing import Optional
from pydantic import BaseModel, Field, ConfigDict


class EntityManifest(BaseModel):
    """Canonical entity registry extracted from PRD Glossary. Immutable."""

    model_config = ConfigDict(frozen=True)

    canonical_names: tuple[str, ...] = Field(default_factory=tuple)
    definitions: dict[str, str] = Field(default_factory=dict)
    features: tuple[str, ...] = Field(default_factory=tuple)
    extraction_error: Optional[str] = None

    @property
    def has_entities(self) -> bool:
        return len(self.canonical_names) > 0

    def constraint_block(self) -> str:
        """
        Hard constraint string injected at the TOP of every Architect prompt.
        Called by ContextBundle.architect_sdd_context() and .architect_api_context().
        """
        if not self.has_entities:
            return "(no entity manifest — proceeding without entity constraints)\n\n"

        lines = [
            "═══════════════════════════════════════════════════════════════",
            "ENTITY MANIFEST — HARD CONSTRAINTS (violations trigger rejection)",
            "═══════════════════════════════════════════════════════════════",
            "",
            "Use these entity names EXACTLY. Any alias or rename = critical violation.",
            "",
            "CANONICAL ENTITIES:",
        ]
        for name, definition in self.definitions.items():
            lines.append(f"  ▸ {name:<22}— {definition}")

        lines.extend(["", "FIELD NAMING:"])
        for name in list(self.canonical_names)[:4]:
            snake = name.lower().replace(" ", "_")
            lines.append(f"  ▸ FK reference to {name}: use '{snake}_id'")

        if self.features:
            lines.extend(["", "FEATURES TO COVER (each needs ≥1 endpoint):"])
            for f in self.features:
                lines.append(f"  ▸ {f}")

        lines.extend(["", "═══════════════════════════════════════════════════════════════", ""])
        return "\n".join(lines)


class ContextBundle(BaseModel):
    """
    FROZEN context object. Marshal assembles it; agents read it.

    Lifecycle:
      1. Marshal builds initial bundle after PRD generation + entity extraction:
         ctx = ContextBundle(prd_content=prd, entity_manifest=manifest)

      2. Marshal creates updated snapshots as pipeline progresses:
         ctx = ctx.model_copy(update={"sdd_content": sdd})
         ctx = ctx.model_copy(update={"api_content": api})

      3. Each agent receives its specific snapshot. It cannot modify it.

    If an agent tries: ctx.sdd_content = "hack"
    Result: pydantic_core.ValidationError: Instance is frozen
    """

    model_config = ConfigDict(frozen=True)

    prd_content: str
    entity_manifest: EntityManifest
    sdd_content: Optional[str] = None
    api_content: Optional[str] = None

    def architect_sdd_context(self, prior_conflicts: list = None) -> str:
        """
        Assembles the full user message for the SDD generation call.
        Called by Marshal before passing to ArchitectAgent.
        Agents do NOT call this — they receive the assembled context from Marshal.
        """
        conflict_section = ""
        if prior_conflicts:
            lines = [
                "CORRECTIONS REQUIRED (fix these in this attempt):",
                "",
            ]
            for i, c in enumerate(prior_conflicts, 1):
                lines.append(f"{i}. [{c.severity.upper()}] {c.description}")
                lines.append(f"   PRD says: {c.prd_reference}")
                lines.append(f"   Previous output had: {c.sdd_reference}")
                lines.append("")
            conflict_section = "\n".join(lines) + "\n"

        return (
            self.entity_manifest.constraint_block()
            + conflict_section
            + "PRD (canonical source of truth):\n\n"
            + self.prd_content
        )

    def architect_api_context(self) -> str:
        """Assembles the full user message for API Spec generation."""
        return (
            self.entity_manifest.constraint_block()
            + "PRD:\n\n"
            + self.prd_content
            + "\n\n---\n\nSDD:\n\n"
            + (self.sdd_content or "")
        )

    def consistency_context(self) -> dict:
        """Returns all data the ConsistencyEngine needs for its check."""
        return {
            "prd_content": self.prd_content,
            "sdd_content": self.sdd_content or "",
            "api_content": self.api_content or "",
            "canonical_names": list(self.canonical_names_flat),
        }

    @property
    def canonical_names_flat(self) -> tuple[str, ...]:
        return self.entity_manifest.canonical_names


class PrdValidationResult(BaseModel):
    """Result of Marshal's PRD structure check. Never seen by agents."""
    model_config = ConfigDict(frozen=True)

    valid: bool
    missing_sections: tuple[str, ...] = Field(default_factory=tuple)
    warnings: tuple[str, ...] = Field(default_factory=tuple)
    has_glossary: bool = False
    has_features: bool = False
    entity_count: int = 0
    feature_count: int = 0
