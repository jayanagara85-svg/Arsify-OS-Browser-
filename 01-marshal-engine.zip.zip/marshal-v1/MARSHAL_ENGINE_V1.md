# Marshal Engine v1 — Design Reference

## What Changed from v2

| Capability | v2 | v1 |
|------------|----|----|
| PRD validation | None | PrdValidator checks structure before passing to Architect |
| Entity extraction | None | EntityExtractor builds canonical name registry from PRD Glossary |
| Context passing | Raw string (PRD text) | ContextBundle (PRD + EntityManifest + SDD + API) |
| Architect prompt | PRD text only | constraint_block + conflicts + PRD text |
| Consistency check | Fuzzy ("does this look consistent?") | Explicit name list ("is 'Member' in these exact places?") |
| Score calculation | LLM-assigned | Deterministic: 100 - (15×critical) - (5×warning) |
| Correction loop | Retry with conflict list | Retry with targeted constraint_block + specific conflict fixes |

---

## Architecture

```
MarshalV1
  ├── ProductAgent          (unchanged from v2)
  ├── PrdValidator          (NEW — structural validation, no LLM)
  ├── EntityExtractor       (NEW — regex first, LLM fallback)
  ├── ContextBundle         (NEW — single context object for all steps)
  ├── ArchitectAgentV1      (UPGRADED — accepts ContextBundle)
  └── ConsistencyEngineV1   (UPGRADED — entity-name-aware)
```

---

## The EntityManifest

The most important new data structure. Built after PRD generation.

```python
EntityManifest(
    canonical_names = ["User", "Task", "Project", "Workspace"],
    definitions = {
        "User": "A registered individual with login credentials",
        "Task": "A unit of work assigned to a User within a Project",
        "Project": "A container for Tasks owned by a Workspace",
        "Workspace": "A shared environment for a team of Users"
    },
    features = ["Task Management", "User Authentication", "Real-time Collaboration"]
)
```

The `constraint_block()` method on this object produces a formatted string:

```
═══════════════════════════════════════════════════════════════
ENTITY MANIFEST — HARD CONSTRAINTS (violations trigger rejection)
═══════════════════════════════════════════════════════════════

CANONICAL ENTITIES:
  ▸ User                 — A registered individual with login credentials
  ▸ Task                 — A unit of work assigned to a User within a Project
  ▸ Project              — A container for Tasks owned by a Workspace
  ▸ Workspace            — A shared environment for a team of Users

FIELD NAMING RULE:
  ▸ Reference to User: use 'user_id' (not any other variant)
  ▸ Reference to Task: use 'task_id'
  ▸ Reference to Project: use 'project_id'

PRD FEATURES TO COVER:
  ▸ Task Management
  ▸ User Authentication
  ▸ Real-time Collaboration
```

This block is injected at the TOP of every Architect Agent system prompt.

---

## Consistency Rules

### Rule 1 — Entity Name Fidelity (CRITICAL)
Every `canonical_names` entry must appear verbatim in:
- SDD `## 3. Data Models` section (as a model heading)
- API spec `components/schemas` (as a schema key)

**Violation:** PRD has `Member`, SDD has `User` → `entity_mismatch` CRITICAL

### Rule 2 — Field Reference Naming (CRITICAL)
When an SDD field references another entity, the field name prefix must match the entity's canonical name.

**Violation:** PRD has `Member`, SDD field is `user_id` → `field_mismatch` CRITICAL  
**Correct:** `member_id` ✓

### Rule 3 — API Endpoint Coverage (WARNING)
Every PRD Feature must be reachable via at least one API endpoint.

**Violation:** PRD Feature "Export Report" has no endpoint → `feature_missing` WARNING

### Rule 4 — SDD/API Endpoint Alignment (WARNING)
Endpoint paths listed in SDD API Surface section must appear in the API spec paths.

**Violation:** SDD lists `POST /reports`, API spec has no `/reports` → `endpoint_mismatch` WARNING

---

## Scoring

```
score = max(0, 100 - (critical_count × 15) - (warning_count × 5))
consistent = (critical_count == 0)
```

| State | Score range | Action |
|-------|-------------|--------|
| Perfect | 100 | Deliver immediately |
| Warnings only | 75–95 | Deliver with score |
| 1 critical | 85 (before warnings) | Retry Architect |
| 2 criticals | 70 (before warnings) | Retry Architect |
| Max retries | Any | Deliver with warnings |

---

## Correction Loop Detail

When `critical_count > 0` and `attempt < MAX_RETRIES`:

1. Marshal extracts the critical conflicts from ConsistencyResult
2. ContextBundle.architect_sdd_context(prior_conflicts=critical) formats them:

```
CONFLICT CORRECTIONS REQUIRED (from previous attempt):
Fix each of these before generating the new SDD.

1. [CRITICAL] PRD Glossary defines entity as 'Member' but SDD Data Models uses 'User'
   PRD says: Glossary: Member — A registered individual with login credentials
   Document had: Data Models: User — fields: id, email, password_hash

```

3. This correction section is prepended to the full constraint_block in the next prompt
4. The model sees: WHAT it got wrong, WHAT the correct name is, and WHICH document it must fix

---

## Limitations

1. **Entity extraction can fail.** If the PRD Glossary is malformed, the regex finds nothing and the LLM fallback may also fail. In this case the pipeline continues without entity constraints — the consistency check reverts to v2 behavior (fuzzy). This is logged as a warning, not an error.

2. **The consistency check is only as good as the PRD Glossary.** If the Product Agent generates a PRD with a vague or incomplete Glossary (e.g., only 2 entities defined), the manifest will be small and the consistency check will miss undeclared entities.

3. **Drift within the correction loop is possible.** When the Architect fixes entity names in retry 1, it may introduce new inconsistencies elsewhere. The consistency check on retry 2 catches these, but at retry 3 (max) the pipeline delivers whatever exists.

4. **Field naming rule (Rule 2) has false positives.** `user_id` may be correct in a system where the entity is genuinely `User`, not `Member`. The consistency engine cannot distinguish "wrong name" from "correct name for a different entity". Ambiguous cases should be reviewed manually.

5. **No semantic consistency checking.** The Marshal Engine validates names and coverage. It does not validate whether the feature descriptions in the PRD logically match the implementation in the SDD. That requires human review.

6. **Context window limits on retry.** By retry attempt 2, the Architect Agent's user message contains: constraint_block + conflict list + PRD (~4000 chars) + SDD instructions. For very detailed PRDs, this may approach the model's context limit. Monitor token usage on briefs > 500 words.

---

## Files Introduced in v1

```
core/
  marshal_v1.py            — Full pipeline with 9 steps
  entity_extractor.py      — EntityManifest builder (regex + LLM)
  prd_validator.py         — PRD structural validator (no LLM)
  architect_agent_v1.py    — ContextBundle-aware architect
  consistency_engine_v1.py — Entity-name-aware consistency check

models/
  v1_schemas.py            — EntityManifest, ContextBundle, PrdValidationResult

prompts/
  entity_extract.txt       — JSON extraction prompt for EntityExtractor
```

All v2 files remain unchanged. MarshalV1 replaces Marshal in main.py by
changing one import and one instantiation line.
