"""
Pipeline router — implements exactly the three pipeline_engine endpoints from SDD §4:

  POST /pipeline/run
  GET  /pipeline/status/{session_id}
  GET  /pipeline/output/{session_id}

No extra endpoints. No missing endpoints.
"""

import logging

from fastapi import APIRouter, BackgroundTasks, HTTPException, Request

from ..models.schemas import (
    OutputBundle,
    PipelineRequest,
    PipelineRunResponse,
    PipelineStatus,
    Session,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/pipeline", tags=["pipeline"])


# ── POST /pipeline/run ────────────────────────────────────────────────────────

@router.post("/run", response_model=PipelineRunResponse, status_code=202)
async def run_pipeline(
    request:          PipelineRequest,
    background_tasks: BackgroundTasks,
    req:              Request,
):
    """
    Start a pipeline session.

    Accepts a product brief (50–2000 chars).
    Returns session_id immediately with status "queued".
    Pipeline runs as a background task.
    Poll /pipeline/status/{session_id} for progress.
    """
    marshal = req.app.state.marshal

    session_id = marshal.create_session(request.brief)
    background_tasks.add_task(marshal.run, session_id, request.brief)

    logger.info(f"[{session_id}] Pipeline queued")
    return PipelineRunResponse(session_id=session_id)


# ── GET /pipeline/status/{session_id} ────────────────────────────────────────

@router.get("/status/{session_id}", response_model=Session)
async def get_status(session_id: str, req: Request):
    """
    Return the current pipeline status and step for a session.

    Returns the full Session object.
    404 if session_id is not found.
    """
    marshal = req.app.state.marshal
    state   = marshal.session_manager.get(session_id)

    if state is None:
        raise HTTPException(
            status_code=404,
            detail=f"Session not found: {session_id}",
        )

    return state


# ── GET /pipeline/output/{session_id} ────────────────────────────────────────

@router.get("/output/{session_id}", response_model=OutputBundle)
async def get_output(session_id: str, req: Request):
    """
    Return the OutputBundle for a completed session.

    404 if session is not found or pipeline is not yet complete.
    500 if session completed but output files are missing (storage error).
    """
    marshal    = req.app.state.marshal
    file_store = marshal.file_store
    state      = marshal.session_manager.get(session_id)

    if state is None:
        raise HTTPException(
            status_code=404,
            detail=f"Session not found: {session_id}",
        )

    if state.status == PipelineStatus.FAILED:
        raise HTTPException(
            status_code=500,
            detail={"message": "Pipeline failed", "error": state.error},
        )

    if state.status != PipelineStatus.COMPLETE:
        raise HTTPException(
            status_code=404,
            detail={
                "message": "Pipeline not complete",
                "status":  state.status,
                "step":    state.step,
            },
        )

    # Read the three output files from disk
    try:
        outputs = {
            "prd":      file_store.read(session_id, "prd.md"),
            "sdd":      file_store.read(session_id, "sdd.md"),
            "api_spec": file_store.read(session_id, "api_spec.yaml"),
        }
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Output file missing for completed session: {exc}",
        )

    return OutputBundle(
        session_id=session_id,
        status=state.status,
        consistency_score=state.consistency_score,
        consistency_result=state.consistency_result,
        outputs=outputs,
    )
