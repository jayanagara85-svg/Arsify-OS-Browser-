"""
Upshalter pipeline_engine — FastAPI application entry point.

SDD §4 endpoints implemented:
  GET  /health
  POST /pipeline/run
  GET  /pipeline/status/{session_id}
  GET  /pipeline/output/{session_id}

CORS: allow_origins=["*"] — restricted at api_hub level (SDD §7).
"""

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import pipeline_router
from .services.marshal import Marshal

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

# ── Config from environment ───────────────────────────────────────────────────

LLM_GATEWAY_URL = os.environ.get("PIPELINE_LLM_GATEWAY", "http://or_gateway:4000")
STORAGE_PATH    = os.environ.get("PIPELINE_STORAGE_PATH", "/pipeline_outputs")


# ── App lifespan ──────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(
        f"pipeline_engine starting — "
        f"gateway={LLM_GATEWAY_URL}, storage={STORAGE_PATH}"
    )
    app.state.marshal = Marshal(
        llm_gateway_url=LLM_GATEWAY_URL,
        storage_base=STORAGE_PATH,
    )
    yield
    logger.info("pipeline_engine shutting down")


# ── FastAPI app ───────────────────────────────────────────────────────────────

app = FastAPI(
    title="Upshalter Pipeline Engine",
    description=(
        "Consistency-aware document generation: "
        "Brief → PRD → SDD → API Spec"
    ),
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],    # Restricted at api_hub level per SDD §7
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


# ── Health endpoint (SDD §4) ──────────────────────────────────────────────────

@app.get("/health", tags=["health"])
async def health():
    return {"status": "ok", "service": "pipeline_engine", "version": "2.0.0"}


# ── Pipeline router ───────────────────────────────────────────────────────────

app.include_router(pipeline_router)
