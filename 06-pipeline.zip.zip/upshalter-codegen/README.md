# Upshalter Workspace v2 — Generated Codebase

**Generated from:** PRD v2.0.0-mvp + SDD v2.0.0-mvp + API Spec  
**Pattern:** Deterministic implementation — no invented features  
**Deviations from SDD:** See `VALIDATION_NOTES.md`

---

## Project Structure

```
/
├── backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   └── app/
│       ├── main.py                      # FastAPI app, lifespan, health endpoint
│       ├── models/
│       │   └── schemas.py               # All Pydantic models — exact SDD mirror
│       ├── routers/
│       │   └── pipeline.py              # POST /run, GET /status, GET /output
│       ├── services/
│       │   ├── marshal.py               # Orchestrator — pipeline lifecycle + retry
│       │   ├── product_agent.py         # PRD generator
│       │   ├── architect_agent.py       # SDD + API Spec generator
│       │   ├── consistency_engine.py    # Cross-document validator
│       │   ├── session_manager.py       # Session state via file_store
│       │   ├── file_store.py            # All filesystem I/O (ADR-001)
│       │   └── llm_client.py            # Shared httpx wrapper for or_gateway
│       └── prompts/                     # LLM system prompts (copied from source)
│           ├── product_prd.txt
│           ├── architect_sdd.txt
│           ├── architect_api.txt
│           └── consistency_check.txt
├── frontend/
│   └── index.html                       # Minimal UI — no framework
├── infra/
│   └── litellm/
│       └── config.yaml                  # or_gateway model routing config
├── docker-compose.yml                   # Local dev (mirrors Sumopod topology)
├── .env.example                         # Copy to .env and fill in values
└── VALIDATION_NOTES.md                  # All SDD deviations documented
```

---

## Quickstart — Local Development

### 1. Copy and fill environment variables

```bash
cp .env.example .env
# Edit .env — OPENROUTER_API_KEY and LITELLM_MASTER_KEY are required
```

### 2. Start services

```bash
docker compose up --build
```

Services started:
- `pipeline_engine` → http://localhost:8001
- `or_gateway` (LiteLLM) → http://localhost:4000
- `frontend` (nginx serving index.html) → http://localhost:3000

### 3. Open the UI

```
http://localhost:3000
```

Set API base URL to `http://localhost:8001` in the UI config row.

---

## Direct API Usage

### Run a pipeline

```bash
curl -X POST http://localhost:8001/pipeline/run \
  -H "Content-Type: application/json" \
  -d '{
    "brief": "A task management app for remote teams where each workspace has projects, tasks, and members with role-based access control. Members can be admin or contributor. Tasks have status, priority, due dates, and can be assigned to members."
  }'

# Response: {"session_id": "3f2a1b...", "status": "queued"}
```

### Poll status

```bash
curl http://localhost:8001/pipeline/status/{session_id}
```

Status values: `queued` → `generating_prd` → `generating_sdd` → `generating_api_spec` → `validating_consistency` → `complete`

### Get output

```bash
curl http://localhost:8001/pipeline/output/{session_id}
```

Response includes:
- `outputs.prd` — full PRD markdown
- `outputs.sdd` — full SDD markdown
- `outputs.api_spec` — full OpenAPI 3.0.3 YAML
- `consistency_score` — 0–100
- `consistency_result` — conflict list and summary

### Health check

```bash
curl http://localhost:8001/health
# {"status": "ok", "service": "pipeline_engine", "version": "2.0.0"}
```

---

## Production Deployment (Sumopod VPS)

Use the existing `docker-compose.sumopod.yml` from the source project.
The `backend/` directory replaces the existing `backend/pipeline_engine/` directory.

```bash
# On Sumopod VPS
cd /opt/upshalter-v2
cp -r /path/to/generated/backend/app backend/pipeline_engine/app
docker compose -f docker-compose.sumopod.yml up --build pipeline_engine
```

---

## Error Reference

| HTTP | Condition | Body |
|------|-----------|------|
| 202 | Pipeline queued | `{session_id, status: "queued"}` |
| 404 | Session not found | `{detail: "Session not found: ..."}` |
| 404 | Output before complete | `{message: "Pipeline not complete", status, step}` |
| 422 | Brief < 50 chars | Pydantic validation error with message |
| 422 | Brief > 2000 chars | Pydantic validation error |
| 500 | Pipeline failed | `{message: "Pipeline failed", error: "..."}` |
| 500 | Output files missing | `{detail: "Output file missing..."}` |

---

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `OPENROUTER_API_KEY` | Yes | — | OpenRouter API key |
| `LITELLM_MASTER_KEY` | Yes | — | LiteLLM gateway auth key |
| `CLODE_HOST` | Yes | — | Redis host for LLM caching |
| `API_HUB_SECRET` | Yes | — | Shared secret for api_hub auth |
| `PIPELINE_MAX_RETRIES` | No | `2` | Max Architect retry attempts |
| `PIPELINE_TIMEOUT_SECONDS` | No | `180` | Overall pipeline timeout |
| `PIPELINE_LLM_GATEWAY` | No | `http://or_gateway:4000` | LiteLLM gateway URL |
| `PIPELINE_STORAGE_PATH` | No | `/pipeline_outputs` | Session output volume path |
