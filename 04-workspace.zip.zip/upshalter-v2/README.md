# Upshalter Workspace v2 — MVP

**Idea → PRD → SDD → API Spec. Consistent. Autonomous. Real.**

---

## What This Is

Upshalter v2 is a three-agent document generation pipeline. You give it one paragraph. It returns three
professionally structured, internally consistent documents:

- `prd.md` — Product Requirements Document
- `sdd.md` — System Design Document
- `api_spec.yaml` — OpenAPI 3.0 Specification

The consistency between these three documents is the intelligence. Any entity name that appears in the PRD
appears verbatim in the SDD schema definitions and the API spec components. The Consistency Engine enforces
this and retries the Architect Agent if contradictions are found.

## What This Is Not

- Not a code generator (Phase 3)
- Not a multi-user SaaS (Phase 4)
- Not a full AI Operating System (Phase 5+)
- Not a demo or prototype

## Architecture

```
Hostinger VPS          Sumopod VPS
─────────────          ────────────────────────────────────────
nginx                  Traefik (internal router)
Paperclip UI    ──▶    api_hub (FastAPI gateway)
                              │
                              ▼
                       pipeline_engine (NEW)
                         ├── Marshal         (orchestrator)
                         ├── Product Agent   (PRD)
                         ├── Architect Agent (SDD + API Spec)
                         └── Consistency Engine (validator)
                              │
                              ▼ calls
                       LiteLLM / or_gateway
                       (upshalter/smart → 4-tier routing)
                              │
                              ▼ writes
                       /pipeline_outputs/{session_id}/
                         ├── prd.md
                         ├── sdd.md
                         ├── api_spec.yaml
                         └── session.json
```

## Quick Start

### Prerequisites

- Two VPS: Hostinger (frontend) + Sumopod (backend)
- Docker + Docker Compose on both
- OpenRouter API key
- Domain: workspace.upshalter.com

### 1. Configure environment

```bash
cp .env.example .env
# Fill in all required values
```

### 2. Deploy Sumopod (backend)

```bash
scp -r backend/ infra/ sumopod-user@SUMOPOD_IP:/opt/upshalter/
ssh sumopod-user@SUMOPOD_IP
cd /opt/upshalter
docker compose -f docker-compose.sumopod.yml up -d
```

### 3. Deploy Hostinger (frontend)

```bash
scp -r frontend/ hostinger-user@HOSTINGER_IP:/opt/upshalter/
ssh hostinger-user@HOSTINGER_IP
cd /opt/upshalter
docker compose -f docker-compose.hostinger.yml up -d
```

### 4. Test the pipeline

```bash
curl -X POST https://workspace.upshalter.com/api/pipeline/run \
  -H "Content-Type: application/json" \
  -H "X-Api-Key: YOUR_API_SECRET" \
  -d '{"brief": "A task management app for remote engineering teams with async standup reports and GitHub integration."}'

# Returns: {"session_id": "uuid", "status": "queued"}

# Poll status
curl https://workspace.upshalter.com/api/pipeline/status/SESSION_ID \
  -H "X-Api-Key: YOUR_API_SECRET"

# Get output
curl https://workspace.upshalter.com/api/pipeline/output/SESSION_ID \
  -H "X-Api-Key: YOUR_API_SECRET"
```

## Project Structure

```
upshalter-v2/
├── README.md
├── .env.example
├── docker-compose.hostinger.yml    # Hostinger VPS services
├── docker-compose.sumopod.yml      # Sumopod VPS services
│
├── docs/
│   ├── PRD.md                      # Product requirements for Upshalter MVP
│   ├── SDD.md                      # System design document
│   ├── ADR.md                      # Architecture decision records
│   └── architecture.md             # Full system architecture reference
│
├── backend/
│   ├── pipeline_engine/            # NEW: core intelligence service
│   │   ├── Dockerfile
│   │   ├── requirements.txt
│   │   ├── main.py                 # FastAPI app
│   │   ├── core/
│   │   │   ├── marshal.py          # Orchestrator + retry logic
│   │   │   ├── product_agent.py    # PRD generator
│   │   │   ├── architect_agent.py  # SDD + API Spec generator
│   │   │   ├── consistency_engine.py
│   │   │   └── session.py          # Session lifecycle
│   │   ├── models/
│   │   │   └── schemas.py          # Pydantic models
│   │   ├── storage/
│   │   │   └── file_store.py       # Volume I/O
│   │   └── prompts/
│   │       ├── marshal_validate.txt
│   │       ├── product_prd.txt
│   │       ├── architect_sdd.txt
│   │       ├── architect_api.txt
│   │       └── consistency_check.txt
│   │
│   └── api_hub/
│       ├── Dockerfile
│       ├── requirements.txt
│       └── main.py                 # Extended gateway (adds /pipeline/*)
│
├── frontend/
│   ├── nginx/
│   │   ├── nginx.conf
│   │   └── conf.d/default.conf
│   └── paperclip/
│       └── paperclip.env
│
└── infra/
    ├── litellm/
    │   └── config.yaml             # Existing model routing (unchanged)
    ├── traefik/
    │   └── traefik.yml
    └── scripts/
        ├── deploy_sumopod.sh
        └── health_check.sh
```

## Success Criteria

| Criterion | Target |
|-----------|--------|
| Input → Output | 1 brief → 3 documents |
| Consistency | Zero critical contradictions across all 3 docs |
| Dev-ready | Real developer can start building from output without re-asking |
| Runtime | Full pipeline completes in < 3 minutes |
| Infrastructure | Runs on existing Sumopod VPS, no new external services |

## Phase 3 (Not in this release)

- Code generation agent
- Deployment runbook agent
- Multi-session history
- Vector memory for cross-session context

---

*Upshalter v2 · MVP Freeze · Build starts here.*
