# Product Requirements Document
## Upshalter Workspace v2 — MVP

**Version:** 2.0.0-mvp  
**Status:** Frozen  
**Owner:** Upshalter  

---

## 1. Product Overview

Upshalter Workspace v2 is a consistency-aware document generation system. It accepts a single product brief
as input and autonomously produces three professional technical documents — a Product Requirements Document,
a System Design Document, and an OpenAPI Specification — that are internally consistent with each other.

The product solves a specific, real problem: technical documentation written by multiple people (or multiple
AI calls) contains contradictions. Entity names drift between documents. API endpoints are defined that the
system design never mentions. Data models are specified that the PRD never justified. Upshalter v2 treats
cross-document consistency as a first-class output requirement, not an afterthought.

---

## 2. Problem Statement

**Who is affected:** Solo founders and early-stage startup teams (1–5 people) who have a product idea and
need to move from concept to structured technical planning before writing code.

**Current pain:**
- Writing PRD, SDD, and API spec as separate documents is slow (4–8 hours minimum per document)
- Documents written at different times use different terminology for the same concepts
- A developer receiving these three documents must reconcile contradictions before starting work
- Existing AI tools generate each document in isolation — no consistency enforcement exists

**Consequence of the problem:** Engineers waste 2–5 hours per project starter reconciling documentation
before writing a single line of code. Solo founders skip documentation entirely and pay the cost in
rework during development.

---

## 3. Target Users

### Primary Persona: The Solo Technical Founder

- Builds a product solo or with 1–2 engineers
- Has a clear product idea, weak documentation discipline
- Understands technology but not product management process
- Needs documents to hand off to a contractor or present to early investors
- Time budget for documentation: 30 minutes maximum

### Secondary Persona: The Early-Stage CTO

- Joins a startup that has a brief or pitch deck but no technical documentation
- Needs to rapidly produce architecture docs to onboard engineers
- Must ensure the docs are consistent before handing to team
- Cannot spend > 1 day on documentation before coding begins

---

## 4. Key Features

### Feature: Brief Intake

**Description:** Accept a plain-language product description (minimum 50 characters, maximum 2000
characters) and initiate the document generation pipeline.

**Acceptance Criteria:**
- [ ] System accepts input via REST API endpoint `POST /api/pipeline/run`
- [ ] Input is validated: minimum length 50 chars, maximum 2000 chars
- [ ] Invalid input returns HTTP 422 with descriptive error message
- [ ] Valid input returns a session ID and status `queued` within 2 seconds
- [ ] Session ID is a UUID v4

### Feature: PRD Generation

**Description:** The Product Agent generates a structured PRD from the validated brief using a large
language model. The PRD follows a fixed template and always includes a Glossary of canonical entity names.

**Acceptance Criteria:**
- [ ] PRD contains all 9 required sections (see Glossary: PRD Template Sections)
- [ ] PRD Glossary lists every domain entity mentioned in the Features section
- [ ] Each feature in the PRD includes at least two measurable acceptance criteria
- [ ] PRD is saved as `prd.md` in the session's output directory
- [ ] PRD generation completes in under 60 seconds

### Feature: SDD Generation

**Description:** The Architect Agent reads the complete PRD and generates a System Design Document. The SDD
uses the exact entity names from the PRD Glossary — no renaming, no aliasing.

**Acceptance Criteria:**
- [ ] SDD contains all 7 required sections (see Glossary: SDD Template Sections)
- [ ] Every entity name in the SDD Data Models section matches verbatim an entry in the PRD Glossary
- [ ] SDD is saved as `sdd.md` in the session's output directory
- [ ] SDD generation completes in under 90 seconds

### Feature: API Spec Generation

**Description:** The Architect Agent reads both PRD and SDD, then generates a valid OpenAPI 3.0
specification in YAML format. All schema component names match entities defined in the SDD.

**Acceptance Criteria:**
- [ ] Output is valid OpenAPI 3.0.3 YAML parseable by standard validators
- [ ] Every schema name in `components/schemas` matches a Data Model from the SDD
- [ ] Every endpoint in the spec has at least one corresponding feature in the PRD
- [ ] Every endpoint includes request schema, response schema, and at least one error response
- [ ] File is saved as `api_spec.yaml` in the session's output directory

### Feature: Consistency Validation

**Description:** The Consistency Engine reads all three generated documents and verifies that entity names,
endpoint definitions, and data fields are consistent across all three. On detecting critical
inconsistencies, it signals the Marshal to retry the Architect Agent.

**Acceptance Criteria:**
- [ ] Consistency Engine produces a structured report with `consistent` boolean and `score` 0–100
- [ ] Entity name mismatches between PRD Glossary and SDD Data Models are flagged as critical conflicts
- [ ] Missing API endpoints for PRD features are flagged as warnings
- [ ] Marshal retries the Architect Agent up to 2 times on critical conflicts
- [ ] Final output includes consistency score regardless of pass/fail

### Feature: Output Delivery

**Description:** All three documents plus a session metadata file are retrievable via the API after
pipeline completion.

**Acceptance Criteria:**
- [ ] `GET /api/pipeline/status/{session_id}` returns pipeline status and progress step
- [ ] `GET /api/pipeline/output/{session_id}` returns all document contents as JSON
- [ ] Output is available within 10 seconds of pipeline completing
- [ ] Session output persists for at least 24 hours on the server volume

---

## 5. User Flows

### Primary Flow: Generate Documents from Brief

```
1. User opens Paperclip UI at workspace.upshalter.com
2. User types or pastes a product brief into the input field
3. User submits → UI shows "Pipeline running..." with step indicator
4. System runs pipeline:
   - Step 1/4: Validating brief
   - Step 2/4: Generating PRD
   - Step 3/4: Generating SDD + API Spec
   - Step 4/4: Validating consistency
5. UI polls GET /api/pipeline/status every 5 seconds
6. On completion, UI renders three document tabs: PRD | SDD | API Spec
7. User downloads individual files or copies content
```

### Error Flow: Brief Too Short

```
1. User submits brief with fewer than 50 characters
2. System returns HTTP 422: "Brief must be at least 50 characters. Add more context about your product."
3. UI shows inline validation error
4. Pipeline is NOT initiated
```

### Error Flow: Consistency Failure After Max Retries

```
1. Pipeline runs ProductAgent → ArchitectAgent → ConsistencyEngine
2. ConsistencyEngine finds critical entity mismatch
3. Marshal retries ArchitectAgent (attempt 2)
4. ConsistencyEngine still finds critical mismatch
5. Marshal retries ArchitectAgent (attempt 3, final)
6. ConsistencyEngine result returned as-is with consistency_score < 100
7. Output delivered with warning: "Consistency score: XX/100. Review flagged conflicts before use."
```

---

## 6. Non-Functional Requirements

| Requirement | Target |
|-------------|--------|
| End-to-end latency (p50) | < 180 seconds |
| API response for run initiation | < 2 seconds |
| Output file persistence | 24 hours minimum |
| Concurrent pipeline sessions | 3 (single VPS constraint) |
| LLM cost per run (target) | < $0.15 USD |
| Retry overhead | < 30% total runtime increase on 1 retry |

---

## 7. Constraints and Assumptions

**Constraints:**
- System runs on a single Sumopod VPS; no horizontal scaling in this phase
- LLM calls go through OpenRouter via LiteLLM; no direct API access to model providers
- Brief input is English only (multi-language is out of scope)
- No user authentication in MVP; API key authentication only
- Output files are stored on the VPS volume; no cloud storage integration

**Assumptions:**
- The brief is a product idea. Non-product inputs (poems, questions) will produce nonsensical output.
  The system does not validate the semantic content of the brief beyond length.
- LLM output will sometimes require 2 retries to pass consistency validation. This is expected behavior,
  not a bug.
- A single Sumopod VPS can handle 3 concurrent sessions with the current model choices.

---

## 8. Out of Scope

- Code generation of any kind
- Deployment runbooks or infrastructure specs
- Frontend UI code generation
- Database design beyond what appears in the SDD
- GTM strategy, marketing copy, or pitch deck generation
- Multi-user access, teams, or workspaces
- Persistent history across sessions
- Email delivery of output documents
- Integration with GitHub, Notion, or any third-party tools

---

## 9. Glossary

| Term | Definition |
|------|------------|
| **Brief** | A plain-language description of a product idea. Minimum 50 characters, maximum 2000 characters. The sole input to the pipeline. |
| **Session** | A single pipeline run. Identified by a UUID. Contains all generated files and status metadata. |
| **Pipeline** | The ordered sequence: Brief → Marshal → Product Agent → Architect Agent → Consistency Engine → Output. |
| **Marshal** | The orchestrating component. Manages the session lifecycle, sequences agents, handles retry logic. |
| **Product Agent** | The LLM-backed component that generates the PRD from the Brief. |
| **Architect Agent** | The LLM-backed component that generates the SDD and API Spec from the PRD. |
| **Consistency Engine** | The LLM-backed component that validates cross-document entity and endpoint consistency. |
| **PRD** | Product Requirements Document. A structured document defining what the product does, who it serves, and what features it contains. |
| **SDD** | System Design Document. A structured document defining how the product is technically implemented. |
| **API Spec** | OpenAPI 3.0 Specification in YAML format. The machine-readable contract for the product's HTTP API. |
| **Entity** | A named domain concept (e.g., "User", "Task", "Project") that must appear verbatim and consistently across PRD Glossary, SDD Data Models, and API Spec schemas. |
| **Consistency Score** | An integer 0–100 representing how fully the three output documents align. 100 = no conflicts. |
| **Critical Conflict** | A cross-document contradiction that must be resolved before the output is developer-ready. Triggers retry. |
| **Warning** | A cross-document gap that does not block usability but should be reviewed. Does not trigger retry. |
| **PRD Template Sections** | 1. Product Overview, 2. Problem Statement, 3. Target Users, 4. Key Features, 5. User Flows, 6. Non-Functional Requirements, 7. Constraints and Assumptions, 8. Out of Scope, 9. Glossary |
| **SDD Template Sections** | 1. System Overview, 2. Architecture, 3. Data Models, 4. API Surface, 5. Service Interactions, 6. Error Handling, 7. Security |
| **Output Bundle** | The set of files produced by one pipeline Session: prd.md, sdd.md, api_spec.yaml, session.json |
| **LiteLLM** | The model routing gateway (or_gateway). Routes requests to OpenRouter with caching and fallback. |
| **upshalter/smart** | The primary LLM model alias in LiteLLM. Maps to claude-sonnet-4-6 via OpenRouter with gpt-4o fallback. |
