# System Design Document
## Upshalter Workspace v2 — pipeline_engine

**Version:** 2.0.0-mvp  
**Status:** Frozen  

---

## 1. System Overview

The pipeline_engine is a single-container Python service (FastAPI) that implements the four-component
document generation pipeline. It exposes three HTTP endpoints and communicates with:

- **LiteLLM / or_gateway** (internal Docker network) — for all LLM inference calls
- **Filesystem volume** `/pipeline_outputs` — for reading and writing all output files
- **api_hub** (internal Docker network) — the only caller; api_hub proxies external requests

The pipeline_engine does not communicate with the public internet directly. All LLM traffic is routed
through or_gateway which applies caching, rate limiting, and model fallback.

---

## 2. Architecture

```
External                   Sumopod Internal Network
────────                   ──────────────────────────────────────────────

Paperclip UI
    │ HTTPS
    ▼
nginx → Traefik → api_hub (port 8000)
                       │ HTTP POST /pipeline/*
                       ▼
              pipeline_engine (port 8001)
                ├── Marshal
                │     ├── creates Session
                │     ├── calls ProductAgent
                │     ├── calls ArchitectAgent (×1–3)
                │     └── calls ConsistencyEngine
                ├── ProductAgent
                │     └── POST /v1/chat/completions → or_gateway:4000
                ├── ArchitectAgent
                │     └── POST /v1/chat/completions → or_gateway:4000
                └── ConsistencyEngine
                      └── POST /v1/chat/completions → or_gateway:4000
                              │
                              ▼ cached via Redis
                         or_gateway:4000 (LiteLLM)
                              │
                              ▼ OpenRouter
                         upshalter/smart
                         (claude-sonnet-4-6 → gpt-4o fallback)
                              │
                              ▼ writes
                    /pipeline_outputs/{session_id}/
                         prd.md
                         sdd.md
                         api_spec.yaml
                         session.json
```

---

## 3. Data Models

### Session

```python
{
  "session_id": str,          # UUID v4
  "brief": str,               # Original user input
  "status": str,              # queued | generating_prd | generating_sdd |
                              # generating_api_spec | validating_consistency |
                              # complete | failed
  "step": int,                # 0–4 (current pipeline step)
  "attempt": int,             # Current retry attempt (0-indexed)
  "created_at": str,          # ISO 8601 timestamp
  "updated_at": str,          # ISO 8601 timestamp
  "completed_at": str | None, # ISO 8601 timestamp or null
  "consistency_score": int | None,  # 0–100 or null until complete
  "consistency_result": dict | None,
  "error": str | None         # Error message if status == failed
}
```

### ConsistencyResult

```python
{
  "consistent": bool,         # True if no critical conflicts
  "score": int,               # 0–100
  "conflicts": [
    {
      "type": str,            # entity_mismatch | endpoint_mismatch |
                              # field_mismatch | feature_missing
      "description": str,
      "prd_reference": str,
      "sdd_reference": str,
      "severity": str         # critical | warning
    }
  ],
  "summary": str
}
```

### PipelineRequest

```python
{
  "brief": str                # Required. 50–2000 characters.
}
```

### PipelineResponse (run)

```python
{
  "session_id": str,
  "status": str               # always "queued" at this point
}
```

### OutputBundle

```python
{
  "session_id": str,
  "status": str,
  "consistency_score": int | None,
  "outputs": {
    "prd": str,               # Full content of prd.md
    "sdd": str,               # Full content of sdd.md
    "api_spec": str           # Full content of api_spec.yaml
  },
  "consistency_result": ConsistencyResult | None
}
```

---

## 4. API Surface

### pipeline_engine (internal, port 8001)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/pipeline/run` | Start a pipeline session. Returns session_id immediately. Runs pipeline in background. |
| GET | `/pipeline/status/{session_id}` | Returns Session object with current status and step. |
| GET | `/pipeline/output/{session_id}` | Returns OutputBundle. 404 if not complete. |
| GET | `/health` | Health check. Returns `{"status": "ok"}`. |

### api_hub extensions (external-facing, port 8000)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/pipeline/run` | Proxies to pipeline_engine `/pipeline/run`. Requires X-Api-Key header. |
| GET | `/api/pipeline/status/{session_id}` | Proxies to pipeline_engine. Requires X-Api-Key header. |
| GET | `/api/pipeline/output/{session_id}` | Proxies to pipeline_engine. Requires X-Api-Key header. |

---

## 5. Service Interactions

### Pipeline Execution Sequence

```
Marshal.run(session_id, brief)
  │
  ├─ 1. session_manager.update_status("generating_prd", step=1)
  │
  ├─ 2. product_agent.generate(brief, session_id)
  │       ├─ POST or_gateway /v1/chat/completions (model: upshalter/smart)
  │       ├─ file_store.write(session_id, "prd.md", content)
  │       └─ returns prd_content: str
  │
  ├─ [RETRY LOOP, max 3 iterations]
  │   │
  │   ├─ 3. session_manager.update_status("generating_sdd", step=2)
  │   │
  │   ├─ 4. architect_agent.generate_sdd(prd_content, session_id, conflicts)
  │   │       ├─ Constructs prompt: PRD content + prior conflicts (if retry)
  │   │       ├─ POST or_gateway /v1/chat/completions
  │   │       ├─ file_store.write(session_id, "sdd.md", content)
  │   │       └─ returns sdd_content: str
  │   │
  │   ├─ 5. session_manager.update_status("generating_api_spec", step=3)
  │   │
  │   ├─ 6. architect_agent.generate_api_spec(prd_content, sdd_content, session_id)
  │   │       ├─ POST or_gateway /v1/chat/completions
  │   │       ├─ file_store.write(session_id, "api_spec.yaml", content)
  │   │       └─ returns api_content: str
  │   │
  │   ├─ 7. session_manager.update_status("validating_consistency", step=4)
  │   │
  │   ├─ 8. consistency_engine.validate(session_id, prd, sdd, api)
  │   │       ├─ POST or_gateway /v1/chat/completions (JSON response mode)
  │   │       └─ returns ConsistencyResult
  │   │
  │   └─ IF result.consistent OR no critical conflicts → break
  │      ELSE IF attempts < MAX_RETRIES → continue loop with conflicts
  │      ELSE → break (deliver with warnings)
  │
  └─ 9. session_manager.update_status("complete", consistency_score=N)
```

### LLM Call Configuration

All LLM calls use the same parameters unless noted:

| Parameter | Value |
|-----------|-------|
| Gateway URL | `http://or_gateway:4000` |
| Model | `upshalter/smart` |
| Max tokens | 4000 (PRD/SDD), 3000 (API Spec), 1000 (Consistency) |
| Timeout | 120 seconds |
| Retry on 429/5xx | Handled by or_gateway (3 retries with 5s backoff) |

---

## 6. Error Handling

| Error Type | Behavior |
|------------|----------|
| Brief validation failure | HTTP 422, pipeline not started |
| LLM call timeout (> 120s) | Session status → `failed`, error message stored |
| LLM returns empty content | Retry once, then fail with error |
| File write failure | Session status → `failed`, error message stored |
| Consistency max retries exceeded | Pipeline completes with consistency warnings in output |
| Session not found | HTTP 404 |
| Output requested before completion | HTTP 404 with `{"detail": "Pipeline not complete", "status": current_status}` |

---

## 7. Security

- All external traffic goes through nginx (TLS termination) → Traefik → api_hub
- api_hub validates `X-Api-Key` header against `API_HUB_SECRET` env var on every request
- pipeline_engine is not exposed outside the Docker internal network
- or_gateway is not exposed outside the Docker internal network
- No user data is stored beyond the 24-hour session TTL
- Environment secrets are passed via Docker environment variables from `.env`; secrets are never
  written to files or logged
- LLM responses may contain user brief content; this is acceptable as all data stays on the VPS
