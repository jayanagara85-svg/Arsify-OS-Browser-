# Upshalter Workspace v2 — Architecture Reference

## System Identity

**What Upshalter v2 is:**
A consistency-aware document generation pipeline. One product brief in. Three internally-consistent
technical documents out: PRD, SDD, and OpenAPI Spec.

**What Upshalter v2 is not:**
A code generator. A deployment system. A SaaS platform. A general-purpose AI assistant. A multi-user
workspace. Each of these is a future phase.

---

## Infrastructure Map

```
Internet
   │ HTTPS (443)
   ▼
workspace.upshalter.com
   │
   ▼
┌──────────────────────────────────────────────┐
│  HOSTINGER VPS (Frontend)                    │
│                                              │
│  nginx (SSL termination + routing)           │
│    ├── / → Paperclip UI :3200                │
│    └── /api/* → Sumopod :8080 (HTTP proxy)  │
│                                              │
│  Paperclip UI :3200                          │
│    Role: brief input + document rendering    │
│    Storage: local file (no database)         │
│                                              │
│  certbot (SSL renewal, background)           │
└──────────────────────────────────────────────┘
   │
   │ HTTP (public internet, /api/* forwarded)
   ▼
┌──────────────────────────────────────────────┐
│  SUMOPOD VPS (Backend)                       │
│                                              │
│  Traefik :8080 (internal router)             │
│    └── /api/* → api_hub :8000               │
│                                              │
│  api_hub :8000 (FastAPI gateway)             │
│    ├── POST /api/pipeline/run                │
│    ├── GET  /api/pipeline/status/{id}        │
│    ├── GET  /api/pipeline/output/{id}        │
│    └── POST /api/models/chat                 │
│    (proxies all to pipeline_engine or        │
│     or_gateway on internal Docker network)   │
│                                              │
│  pipeline_engine :8001 (FastAPI, NEW)        │
│    ├── Marshal (orchestrator)                │
│    │     └── sequences agents, retries       │
│    ├── ProductAgent                          │
│    │     └── generates prd.md               │
│    ├── ArchitectAgent                        │
│    │     └── generates sdd.md + api_spec.yaml│
│    └── ConsistencyEngine                     │
│          └── validates cross-doc alignment   │
│                                              │
│  or_gateway :4000 (LiteLLM)                 │
│    ├── upshalter/smart → claude-sonnet-4-6   │
│    ├── Fallback: gpt-4o                      │
│    └── Redis cache (Clode, TTL 1h)           │
│                                              │
│  Docker volume: pipeline_outputs/            │
│    └── {session_id}/                        │
│         ├── prd.md                           │
│         ├── sdd.md                           │
│         ├── api_spec.yaml                   │
│         └── session.json                    │
└──────────────────────────────────────────────┘
   │
   │ Redis (cache only, no session data)
   ▼
┌──────────────────────┐
│  CLODE (External)    │
│  Redis :6379         │
│  (LLM response cache)│
└──────────────────────┘
```

---

## Pipeline Execution

```
User types brief in Paperclip
  │
  ▼ POST /api/pipeline/run {"brief": "..."}
nginx → Traefik → api_hub → pipeline_engine /pipeline/run
  │
  ▼ Returns immediately
{"session_id": "uuid", "status": "queued"}
  │
  ▼ Background task starts
Marshal.run(session_id, brief)

  STEP 1/4 — PRD Generation
  ├── ProductAgent.generate(brief)
  ├── POST or_gateway /v1/chat/completions (upshalter/smart)
  ├── Receives: structured PRD markdown
  └── Writes: /pipeline_outputs/{id}/prd.md

  STEP 2/4 — SDD Generation
  ├── ArchitectAgent.generate_sdd(prd_content)
  ├── POST or_gateway /v1/chat/completions (upshalter/smart)
  ├── Prompt includes: PRD content + prior conflicts (on retry)
  └── Writes: /pipeline_outputs/{id}/sdd.md

  STEP 3/4 — API Spec Generation
  ├── ArchitectAgent.generate_api_spec(prd_content, sdd_content)
  ├── POST or_gateway /v1/chat/completions (upshalter/smart)
  └── Writes: /pipeline_outputs/{id}/api_spec.yaml

  STEP 4/4 — Consistency Validation
  ├── ConsistencyEngine.validate(prd, sdd, api)
  ├── POST or_gateway /v1/chat/completions (JSON mode)
  ├── Returns: {consistent, score, conflicts[]}
  │
  ├── IF critical conflicts AND attempt < MAX_RETRIES:
  │     └── Go back to STEP 2 with conflict list
  │
  └── IF no critical conflicts OR max retries:
        └── Mark session COMPLETE

User polls GET /api/pipeline/status/{id} every 5s
User calls GET /api/pipeline/output/{id} when status == "complete"
```

---

## Service Communication

| From | To | Protocol | Port | Auth |
|------|-----|----------|------|------|
| nginx | Paperclip | HTTP | 3200 | None (internal) |
| nginx | Sumopod Traefik | HTTP | 8080 | None (network) |
| Traefik | api_hub | HTTP | 8000 | None (internal Docker) |
| api_hub | pipeline_engine | HTTP | 8001 | None (internal Docker) |
| api_hub | or_gateway | HTTP | 4000 | None (internal Docker) |
| pipeline_engine | or_gateway | HTTP | 4000 | None (internal Docker) |
| or_gateway | Clode Redis | TCP | 6379 | None (Clode network) |
| or_gateway | OpenRouter | HTTPS | 443 | OPENROUTER_API_KEY |
| External clients | nginx | HTTPS | 443 | X-Api-Key header |

---

## Removed Services (v1 → v2)

| Service | v1 | v2 | Reason |
|---------|----|----|--------|
| OpenHands | ✓ | ✗ | Code execution agent — not needed for doc generation |
| n8n engine | ✓ | ✗ | Marshal replaces workflow orchestration in code |
| n8n worker | ✓ | ✗ | Removed with n8n |
| n8n_proxy (Hostinger) | ✓ | ✗ | Removed with n8n |
| OpenCode UI | ✓ | ✗ | Code IDE — not in scope |
| Grafana | ✓ | ✗ | Monitoring — not in v2 scope |
| PostgreSQL (Clode) | ✓ | ✗ | No service needs relational DB |
| Vector DB | ✗ (planned) | ✗ | File context sufficient for Phase 2 |

**Container count: 15+ → 5 active services**

---

## Data Flow: File Storage

```
pipeline_outputs/                    ← Docker volume on Sumopod
└── {session_id}/                    ← UUID v4, one directory per pipeline run
    ├── session.json                 ← Status, timestamps, consistency score
    ├── prd.md                       ← Generated by ProductAgent
    ├── sdd.md                       ← Generated by ArchitectAgent
    └── api_spec.yaml               ← Generated by ArchitectAgent
```

**session.json structure:**
```json
{
  "session_id": "3f2a...",
  "brief": "A task management app for...",
  "status": "complete",
  "step": 4,
  "attempt": 1,
  "created_at": "2025-01-01T10:00:00Z",
  "updated_at": "2025-01-01T10:02:30Z",
  "completed_at": "2025-01-01T10:02:30Z",
  "consistency_score": 92,
  "consistency_result": {
    "consistent": true,
    "score": 92,
    "conflicts": [...],
    "summary": "..."
  },
  "error": null
}
```

---

## Environment Variables

| Variable | Used By | Required |
|----------|---------|----------|
| `OPENROUTER_API_KEY` | or_gateway | Yes |
| `API_HUB_SECRET` | api_hub + all callers | Yes |
| `LITELLM_MASTER_KEY` | or_gateway | Yes |
| `SUMOPOD_IP` | nginx (Hostinger) | Yes |
| `PAPERCLIP_SECRET` | paperclip | Yes |
| `SSL_EMAIL` | certbot | Yes |
| `CLODE_HOST` | or_gateway (Redis) | Yes |
| `PIPELINE_MAX_RETRIES` | pipeline_engine | No (default: 2) |
| `PIPELINE_TIMEOUT_SECONDS` | pipeline_engine | No (default: 180) |
