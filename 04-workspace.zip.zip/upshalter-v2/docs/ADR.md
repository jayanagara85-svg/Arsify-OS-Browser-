# Architecture Decision Records
## Upshalter Workspace v2

---

## ADR-001: File-Based Storage Instead of Database

**Status:** Accepted  
**Date:** 2025  

### Context

The previous system (v1) used PostgreSQL on Clode for session storage, OpenHands conversation history,
and n8n workflow execution data. PostgreSQL was a shared datastore accessed by three different services
without connection pooling, identified in Phase 0 as a critical risk (deadlock potential at agent load).

For v2, a storage decision must be made for pipeline session data and generated document content.

### Decision

Use the filesystem. Each session writes to `/pipeline_outputs/{session_id}/` containing four files:
`prd.md`, `sdd.md`, `api_spec.yaml`, and `session.json`. The directory is a Docker volume mount on
the Sumopod VPS.

### Reasoning

**1. The data is inherently file-shaped.**
PRD, SDD, and API Spec are documents. Storing documents as records in a relational database and then
reconstructing them for delivery adds no value. The files are the canonical form.

**2. The access pattern is write-once, read-few.**
A session is written by one pipeline run and read at most a handful of times by the user. There is no
relational querying, no joins, no aggregation, no concurrent writes to the same session. A database
adds no capability for this access pattern — only operational complexity and a network round-trip.

**3. Removing PostgreSQL eliminates an external dependency and a critical risk.**
The Phase 0 audit identified the shared Clode PostgreSQL as a single point of failure with no connection
pooling. Removing it entirely eliminates that risk. The Redis instance on Clode is retained — but only
for LiteLLM response caching, which is stateless and tolerates loss.

**4. The file system is auditable without tooling.**
A developer troubleshooting a failed session can SSH into the VPS and read `session.json` directly.
No database client, no query, no schema migration. The operational cost is zero.

### Consequences

- Sessions are not queryable beyond "does this session_id exist".
- No session history across restarts (acceptable: output persists in files, session.json survives restarts).
- A cleanup cron job must be added to delete sessions older than 24 hours (implementation: Phase 3).
- No multi-user access patterns are possible without significant redesign (accepted: out of scope).

### Alternatives Rejected

| Alternative | Rejection Reason |
|-------------|-----------------|
| PostgreSQL (Clode) | Eliminates external dependency; access pattern doesn't justify relational DB |
| SQLite | Adds ORM complexity for data that is natively file-shaped |
| Redis (Clode) | Redis is retained for LLM caching only; mixing session storage into it creates coupling |

---

## ADR-002: Marshal Replaces n8n for Pipeline Orchestration

**Status:** Accepted  
**Date:** 2025  

### Context

The v1 system used n8n as its workflow engine for any automation that required sequencing steps. n8n
ran on Sumopod with a worker process, used PostgreSQL for workflow state, and was proxied via Hostinger
for UI access. The Phase 0 audit confirmed that n8n was configured but no document generation workflow
existed — it was infrastructure waiting for a workflow to be written.

### Decision

Remove n8n entirely. Implement pipeline orchestration as a Python class (`Marshal`) inside the
`pipeline_engine` service.

### Reasoning

**1. n8n solves a different problem.**
n8n's value is visual workflow building for non-programmers, webhook integration, and connecting
third-party services without code. The Upshalter pipeline is: call LLM → write file → call LLM →
write file → call LLM → read all files → decide. This is 30 lines of Python `async` code. It does not
benefit from a visual canvas.

**2. Retry logic requires conditional branching that is cumbersome in n8n.**
The consistency retry loop (if conflicts detected, re-run Architect with conflict context) is a
stateful conditional loop. In n8n, this requires custom Function nodes, loop constructs, and careful
session state management. In Python, it is a `for` loop with a `break` condition.

**3. n8n adds two containers and a PostgreSQL dependency for zero capability gain.**
The Phase 2 architecture reduces 18+ containers to 9. Keeping n8n would require keeping PostgreSQL
for n8n state and the n8n worker for queue processing — three containers and one external service
for a workflow that Python handles in 30 lines.

**4. Code is version-controlled. n8n workflows are not.**
Pipeline logic written as Python is committed to Git, reviewable via PR, testable with pytest, and
deployable via the same Docker build process as the rest of the system. n8n workflows are JSON blobs
in a database that require n8n's export feature to version.

### Consequences

- Pipeline changes require a code change and container rebuild (vs. editing a n8n workflow in UI).
  This is acceptable: the pipeline logic is stable and frozen for Phase 2.
- Debugging requires reading Python logs instead of n8n's execution history UI.
  Mitigation: structured logging with step/attempt context in every log line.

### Alternatives Rejected

| Alternative | Rejection Reason |
|-------------|-----------------|
| Keep n8n, write the workflow | Still requires PostgreSQL + worker; orchestration logic too complex for n8n nodes |
| Use Prefect or Airflow | Complete overkill for a 4-step sequential pipeline |
| Use Celery | Adds broker dependency (Redis configuration complexity); no benefit over asyncio for this use case |

---

## ADR-003: Single pipeline_engine Container Instead of Microservices

**Status:** Accepted  
**Date:** 2025  

### Context

The v2 system introduces Marshal, ProductAgent, ArchitectAgent, and ConsistencyEngine as new components.
A natural architectural question is whether each of these should be a separate microservice with its own
container, network interface, and deployment lifecycle.

### Decision

All four components live in a single Python process inside a single container (`pipeline_engine`). They
are implemented as Python classes that call each other's methods directly. They share a single filesystem
mount and a single environment configuration.

### Reasoning

**1. The components are not independently scalable.**
ProductAgent must finish before ArchitectAgent starts. ArchitectAgent must finish before ConsistencyEngine
runs. There is no parallelism to exploit. The primary benefit of microservices — independent horizontal
scaling — is irrelevant for a sequential pipeline.

**2. The inter-component communication is not network communication.**
In a Python monolith, ProductAgent returns a string to Marshal, which passes it to ArchitectAgent.
In a microservice architecture, that string must be serialized to JSON, transmitted over HTTP, and
deserialized. The overhead is non-zero and the failure modes multiply: network timeouts, serialization
errors, service discovery failures. None of this overhead buys anything.

**3. The Sumopod VPS has finite resources.**
Each Docker container has a fixed memory and CPU overhead. Four containers for four components
multiplies resource consumption by roughly 4× compared to one container. At the scale of 3 concurrent
sessions on a single VPS, this matters.

**4. Operational simplicity is a success criterion.**
The system must "run in single VPS" (Strategic Lock, Step 6). One container is one `docker logs`
command, one health check endpoint, one build pipeline. Four containers is four of each.

### Consequences

- Marshal, ProductAgent, ArchitectAgent, and ConsistencyEngine cannot be deployed or scaled
  independently. This is accepted: independent scaling is not a Phase 2 requirement.
- A crash in any component crashes the entire pipeline_engine process. Mitigation: the FastAPI
  BackgroundTasks framework isolates individual session failures; a crash in one session does not
  affect others.
- Refactoring to microservices in Phase 4 will require extracting each class into its own service.
  The interfaces are clean Python classes with typed method signatures — this extraction is
  straightforward when the time comes.

### Alternatives Rejected

| Alternative | Rejection Reason |
|-------------|-----------------|
| One container per agent | Multiplies resource consumption, adds network calls, no parallelism benefit |
| OpenHands as the execution agent | OpenHands is a code execution agent; we're generating structured text, not running code |
| Serverless functions | No serverless runtime available on bare VPS; cold start latency unacceptable |

---

## ADR-004: Prompt Engineering as the Primary Intelligence Layer

**Status:** Accepted  
**Date:** 2025  

### Context

The Consistency Engine must detect contradictions between three documents. This could be implemented
as deterministic code (regex/parsing) or as an LLM call. Similarly, the Architect Agent's use of PRD
entity names could be enforced programmatically (post-process and replace) or via prompt design.

### Decision

Use LLM calls for all intelligence tasks, including consistency checking. Enforce entity name consistency
through prompt design (instruction + examples in system prompt) rather than post-processing code.

### Reasoning

**1. Document understanding requires semantic parsing, not string matching.**
The Consistency Engine must determine that "User Account" in the SDD and "Account" in the PRD Glossary
refer to the same entity — or that they don't. This semantic judgment is exactly what LLMs are built
for. A regex cannot make this judgment. A rule-based parser would require a hand-crafted ontology.

**2. Prompt engineering is the appropriate phase for this kind of iteration.**
In Phase 2, the system is being proven out. The right approach is to make prompts excellent, observe
failures, and refine prompts — not to build brittle parsing code that must be rewritten as edge cases
emerge. Prompt iteration takes minutes. Code refactoring takes hours.

**3. The prompt contract is the interface.**
The system prompt for each agent is the equivalent of a function signature with documentation. It is
version-controlled, readable, and replaceable without touching application code. This is the correct
abstraction boundary.

### Consequences

- Consistency checking quality depends on LLM output quality. The Consistency Engine prompt instructs
  the LLM to respond in strict JSON — output parsing failures are possible and handled with error
  recovery.
- Each pipeline run includes one additional LLM call for consistency checking. At `upshalter/smart`
  (claude-sonnet-4-6) pricing, this adds approximately $0.02–0.04 per run.
- Retry calls (up to 2) add the same cost again. Estimated maximum cost per run: $0.15 USD.
