#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# deploy_sumopod.sh — Deploy Upshalter v2 backend to Sumopod VPS
# Usage: ./infra/scripts/deploy_sumopod.sh
# ─────────────────────────────────────────────────────────────
set -euo pipefail

SUMOPOD_USER="${SUMOPOD_USER:-root}"
SUMOPOD_IP="${SUMOPOD_IP:?Set SUMOPOD_IP environment variable}"
DEPLOY_PATH="/opt/upshalter"

echo "▶ Deploying Upshalter v2 backend to ${SUMOPOD_USER}@${SUMOPOD_IP}"

# 1. Sync files
echo "  Syncing project files..."
rsync -avz --exclude '.git' --exclude '__pycache__' --exclude '*.pyc' \
  backend/ infra/ docker-compose.sumopod.yml .env \
  "${SUMOPOD_USER}@${SUMOPOD_IP}:${DEPLOY_PATH}/"

# 2. Build and deploy
echo "  Building and starting containers..."
ssh "${SUMOPOD_USER}@${SUMOPOD_IP}" << REMOTE
  set -euo pipefail
  cd ${DEPLOY_PATH}

  # Pull base images
  docker compose -f docker-compose.sumopod.yml pull or_gateway watchtower

  # Build custom images
  docker compose -f docker-compose.sumopod.yml build api_hub pipeline_engine

  # Rolling restart — keep or_gateway up during redeploy
  docker compose -f docker-compose.sumopod.yml up -d --no-deps or_gateway
  sleep 5
  docker compose -f docker-compose.sumopod.yml up -d --no-deps traefik
  docker compose -f docker-compose.sumopod.yml up -d --no-deps pipeline_engine
  sleep 5
  docker compose -f docker-compose.sumopod.yml up -d --no-deps api_hub
  docker compose -f docker-compose.sumopod.yml up -d --no-deps watchtower

  echo "Container status:"
  docker compose -f docker-compose.sumopod.yml ps
REMOTE

echo "✓ Sumopod deployment complete"
echo ""
echo "Health check:"
curl -sf "http://${SUMOPOD_IP}:8080/api/health" && echo " api_hub OK" || echo " api_hub UNREACHABLE"
