#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# health_check.sh — Verify all Upshalter v2 services are up
# Run from your local machine after deployment
# ─────────────────────────────────────────────────────────────
set -euo pipefail

SUMOPOD_IP="${SUMOPOD_IP:?Set SUMOPOD_IP}"
API_SECRET="${API_HUB_SECRET:?Set API_HUB_SECRET}"

PASS=0
FAIL=0

check() {
  local name="$1"
  local url="$2"
  local expected="$3"

  if curl -sf -H "X-Api-Key: ${API_SECRET}" "${url}" | grep -q "${expected}"; then
    echo "  ✓ ${name}"
    PASS=$((PASS+1))
  else
    echo "  ✗ ${name} — unexpected response from ${url}"
    FAIL=$((FAIL+1))
  fi
}

check_internal() {
  local name="$1"
  local url="$2"
  local expected="$3"

  if curl -sf "${url}" | grep -q "${expected}"; then
    echo "  ✓ ${name}"
    PASS=$((PASS+1))
  else
    echo "  ✗ ${name} — unreachable at ${url}"
    FAIL=$((FAIL+1))
  fi
}

echo "Upshalter v2 Health Check"
echo "========================="
echo ""

echo "External endpoints (via api_hub):"
check "api_hub /health" \
  "http://${SUMOPOD_IP}:8080/api/health" \
  '"status":"ok"'

echo ""
echo "Internal services (SSH tunnel or from Sumopod):"
# These require being on the Sumopod network — skip gracefully if not available
check_internal "or_gateway /health" \
  "http://${SUMOPOD_IP}:4000/health" \
  '"status"' || true

echo ""
echo "Pipeline smoke test:"
SESSION=$(curl -sf \
  -X POST "http://${SUMOPOD_IP}:8080/api/pipeline/run" \
  -H "Content-Type: application/json" \
  -H "X-Api-Key: ${API_SECRET}" \
  -d '{"brief": "A simple todo list app for personal use with recurring tasks and priority levels."}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['session_id'])" 2>/dev/null || echo "")

if [ -n "${SESSION}" ]; then
  echo "  ✓ Pipeline started — session_id: ${SESSION}"
  echo "    Poll: curl -H 'X-Api-Key: ...' http://${SUMOPOD_IP}:8080/api/pipeline/status/${SESSION}"
  PASS=$((PASS+1))
else
  echo "  ✗ Pipeline failed to start"
  FAIL=$((FAIL+1))
fi

echo ""
echo "Results: ${PASS} passed, ${FAIL} failed"
[ "${FAIL}" -eq 0 ] && exit 0 || exit 1
