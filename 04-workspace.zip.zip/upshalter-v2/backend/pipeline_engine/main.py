import logging
import os
from contextlib import asynccontextmanager

from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .core.marshal import Marshal
from .models.schemas import (
    OutputBundle,
    PipelineRequest,
    PipelineRunResponse,
    PipelineStatus,
    SessionState,
)
from .storage.file_store import FileStore

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

# ── Config from environment ───────────────────────────────────────────────────
LLM_GATEWAY_URL = os.environ.get("PIPELINE_LLM_GATEWAY", "http://or_gateway:4000")
STORAGE_PATH = os.environ.get("PIPELINE_STORAGE_PATH", "/pipeline_outputs")

# ── App lifecycle ─────────────────────────────────────────────────────────────
marshal: Marshal | None = None
file_store: FileStore | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global marshal, file_store
    logger.info(f"Starting pipeline_engine — gateway={LLM_GATEWAY_URL}, storage={STORAGE_PATH}")
    marshal = Marshal(llm_gateway_url=LLM_GATEWAY_URL, storage_base=STORAGE_PATH)
    file_store = FileStore(base_path=STORAGE_PATH)
    yield
    logger.info("pipeline_engine shutting down")


# ── FastAPI app ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="Upshalter Pipeline Engine",
    description="Consistency-aware document generation: Brief → PRD → SDD → API Spec",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restricted at api_hub level
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


# ── Background pipeline runner ────────────────────────────────────────────────
async def _run_pipeline(session_id: str, brief: str) -> None:
    """Background task. Exceptions are caught inside marshal.run()."""
    try:
        await marshal.run(session_id=session_id, brief=brief)
    except Exception:
        # Already logged and stored in session by marshal.run()
        pass


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok", "service": "pipeline_engine", "version": "2.0.0"}


@app.post("/pipeline/run", response_model=PipelineRunResponse, status_code=202)
async def run_pipeline(request: PipelineRequest, background_tasks: BackgroundTasks):
    """
    Start a pipeline session. Returns session_id immediately.
    Pipeline runs in the background.
    Poll /pipeline/status/{session_id} for progress.
    """
    session_id = marshal.create_session(request.brief)
    background_tasks.add_task(_run_pipeline, session_id, request.brief)
    logger.info(f"[{session_id}] Pipeline queued")
    return PipelineRunResponse(session_id=session_id)


@app.get("/pipeline/status/{session_id}", response_model=SessionState)
async def get_status(session_id: str):
    """
    Returns the current pipeline status and step for a session.
    """
    state = marshal.session_manager.get(session_id)
    if state is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    return state


@app.get("/pipeline/output/{session_id}", response_model=OutputBundle)
async def get_output(session_id: str):
    """
    Returns the output bundle for a completed session.
    Returns 404 if session is not complete yet.
    """
    state = marshal.session_manager.get(session_id)
    if state is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")

    if state.status == PipelineStatus.FAILED:
        raise HTTPException(
            status_code=500,
            detail={"message": "Pipeline failed", "error": state.error},
        )

    if state.status != PipelineStatus.COMPLETE:
        raise HTTPException(
            status_code=404,
            detail={
                "message": "Pipeline not complete",
                "status": state.status,
                "step": state.step,
            },
        )

    # Read files from disk
    try:
        outputs = {
            "prd": file_store.read(session_id, "prd.md"),
            "sdd": file_store.read(session_id, "sdd.md"),
            "api_spec": file_store.read(session_id, "api_spec.yaml"),
        }
    except FileNotFoundError as e:
        raise HTTPException(
            status_code=500,
            detail=f"Output file missing for completed session: {e}",
        )

    return OutputBundle(
        session_id=session_id,
        status=state.status,
        consistency_score=state.consistency_score,
        consistency_result=state.consistency_result,
        outputs=outputs,
    )
