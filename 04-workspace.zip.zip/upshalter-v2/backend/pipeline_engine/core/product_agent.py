import logging
from pathlib import Path

import httpx

from ..storage.file_store import FileStore

logger = logging.getLogger(__name__)

PROMPT_PATH = Path(__file__).parent.parent / "prompts" / "product_prd.txt"


class ProductAgent:
    """
    Generates the PRD from the user's brief.
    Single responsibility: one LLM call, one file written.
    """

    MODEL = "upshalter/smart"
    MAX_TOKENS = 4000
    TIMEOUT = 120.0

    def __init__(self, llm_gateway_url: str, file_store: FileStore):
        self.llm_gateway_url = llm_gateway_url
        self.store = file_store
        self._system_prompt = PROMPT_PATH.read_text(encoding="utf-8")

    async def generate(self, brief: str, session_id: str) -> str:
        """
        Generate PRD from brief. Saves prd.md to session dir. Returns content.
        """
        logger.info(f"[{session_id}] ProductAgent: generating PRD")

        content = await self._call_llm(
            messages=[
                {"role": "user", "content": brief}
            ],
            session_id=session_id,
        )

        self.store.write(session_id, "prd.md", content)
        logger.info(f"[{session_id}] ProductAgent: PRD written ({len(content)} chars)")
        return content

    async def _call_llm(self, messages: list[dict], session_id: str) -> str:
        payload = {
            "model": self.MODEL,
            "max_tokens": self.MAX_TOKENS,
            "messages": [
                {"role": "system", "content": self._system_prompt},
                *messages,
            ],
        }

        async with httpx.AsyncClient(timeout=self.TIMEOUT) as client:
            try:
                response = await client.post(
                    f"{self.llm_gateway_url}/v1/chat/completions",
                    json=payload,
                )
                response.raise_for_status()
            except httpx.HTTPStatusError as e:
                logger.error(f"[{session_id}] ProductAgent LLM error {e.response.status_code}: {e.response.text}")
                raise

        data = response.json()
        content = data["choices"][0]["message"]["content"]

        if not content or len(content.strip()) < 100:
            raise ValueError(
                f"[{session_id}] ProductAgent received suspiciously short LLM response ({len(content)} chars)"
            )

        return content.strip()
