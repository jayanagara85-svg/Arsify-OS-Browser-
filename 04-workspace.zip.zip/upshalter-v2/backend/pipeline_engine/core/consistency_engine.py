import json
import logging
import re
from pathlib import Path

import httpx

from ..models.schemas import ConsistencyResult, Conflict, ConflictSeverity, ConflictType

logger = logging.getLogger(__name__)

PROMPT_PATH = Path(__file__).parent.parent / "prompts" / "consistency_check.txt"


class ConsistencyEngine:
    """
    Validates cross-document consistency between PRD, SDD, and API Spec.
    Returns a ConsistencyResult with score and conflicts list.
    
    Uses JSON-mode LLM call. Falls back to conservative result on parse failure.
    """

    MODEL = "upshalter/smart"
    MAX_TOKENS = 1500
    TIMEOUT = 90.0

    def __init__(self, llm_gateway_url: str):
        self.llm_gateway_url = llm_gateway_url
        self._prompt_template = PROMPT_PATH.read_text(encoding="utf-8")

    async def validate(
        self,
        session_id: str,
        prd_content: str,
        sdd_content: str,
        api_content: str,
    ) -> ConsistencyResult:
        """
        Validate consistency. Returns ConsistencyResult.
        On LLM failure: returns conservative result (consistent=False, score=0).
        """
        logger.info(f"[{session_id}] ConsistencyEngine: validating")

        prompt = self._prompt_template.replace(
            "{prd_content}", prd_content
        ).replace(
            "{sdd_content}", sdd_content
        ).replace(
            "{api_content}", api_content
        )

        raw_response = await self._call_llm(prompt, session_id)
        result = self._parse_response(raw_response, session_id)

        logger.info(
            f"[{session_id}] ConsistencyEngine: score={result.score}, "
            f"consistent={result.consistent}, conflicts={len(result.conflicts)}"
        )
        return result

    def _parse_response(self, raw: str, session_id: str) -> ConsistencyResult:
        """Parse JSON response. Returns safe fallback on any parse error."""
        try:
            # Strip markdown fences if present
            cleaned = raw.strip()
            if cleaned.startswith("```json"):
                cleaned = cleaned[7:]
            elif cleaned.startswith("```"):
                cleaned = cleaned[3:]
            if cleaned.endswith("```"):
                cleaned = cleaned[:-3]
            cleaned = cleaned.strip()

            # Extract JSON object if there's surrounding text
            json_match = re.search(r'\{.*\}', cleaned, re.DOTALL)
            if json_match:
                cleaned = json_match.group()

            data = json.loads(cleaned)

            conflicts = []
            for c in data.get("conflicts", []):
                try:
                    conflicts.append(Conflict(
                        type=ConflictType(c.get("type", "entity_mismatch")),
                        description=c.get("description", ""),
                        prd_reference=c.get("prd_reference", ""),
                        sdd_reference=c.get("sdd_reference", ""),
                        severity=ConflictSeverity(c.get("severity", "warning")),
                    ))
                except (ValueError, KeyError) as e:
                    logger.warning(f"[{session_id}] Skipping malformed conflict entry: {e}")

            return ConsistencyResult(
                consistent=bool(data.get("consistent", False)),
                score=int(data.get("score", 0)),
                conflicts=conflicts,
                summary=str(data.get("summary", "Consistency check completed.")),
            )

        except (json.JSONDecodeError, KeyError, ValueError) as e:
            logger.error(f"[{session_id}] ConsistencyEngine failed to parse LLM response: {e}")
            logger.debug(f"[{session_id}] Raw response was: {raw[:500]}")
            # Conservative fallback: treat as non-critical failure
            return ConsistencyResult(
                consistent=True,
                score=50,
                conflicts=[],
                summary=(
                    "Consistency check could not parse the LLM response. "
                    "Documents were accepted with an assumed score of 50. "
                    "Manual review is recommended."
                ),
            )

    async def _call_llm(self, prompt: str, session_id: str) -> str:
        payload = {
            "model": self.MODEL,
            "max_tokens": self.MAX_TOKENS,
            "messages": [
                {
                    "role": "user",
                    "content": prompt,
                }
            ],
            # Request JSON output where supported
            "response_format": {"type": "json_object"},
        }

        async with httpx.AsyncClient(timeout=self.TIMEOUT) as client:
            try:
                response = await client.post(
                    f"{self.llm_gateway_url}/v1/chat/completions",
                    json=payload,
                )
                response.raise_for_status()
            except httpx.HTTPStatusError as e:
                logger.error(
                    f"[{session_id}] ConsistencyEngine LLM error "
                    f"{e.response.status_code}: {e.response.text[:300]}"
                )
                raise

        data = response.json()
        return data["choices"][0]["message"]["content"]
