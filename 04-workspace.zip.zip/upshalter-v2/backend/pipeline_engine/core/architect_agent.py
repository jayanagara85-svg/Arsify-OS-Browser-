import logging
from pathlib import Path
from typing import Optional

import httpx

from ..models.schemas import Conflict
from ..storage.file_store import FileStore

logger = logging.getLogger(__name__)

SDD_PROMPT_PATH = Path(__file__).parent.parent / "prompts" / "architect_sdd.txt"
API_PROMPT_PATH = Path(__file__).parent.parent / "prompts" / "architect_api.txt"


class ArchitectAgent:
    """
    Generates SDD and API Spec from PRD content.
    Reads PRD, writes sdd.md and api_spec.yaml.
    On retry: receives prior conflict list and incorporates fixes.
    """

    MODEL = "upshalter/smart"
    MAX_TOKENS_SDD = 4000
    MAX_TOKENS_API = 3500
    TIMEOUT = 120.0

    def __init__(self, llm_gateway_url: str, file_store: FileStore):
        self.llm_gateway_url = llm_gateway_url
        self.store = file_store
        self._sdd_prompt_template = SDD_PROMPT_PATH.read_text(encoding="utf-8")
        self._api_prompt_template = API_PROMPT_PATH.read_text(encoding="utf-8")

    async def generate_sdd(
        self,
        prd_content: str,
        session_id: str,
        attempt: int = 0,
        previous_conflicts: Optional[list[Conflict]] = None,
    ) -> str:
        """
        Generate SDD from PRD. On retry attempts, pass prior conflicts for correction.
        Saves sdd.md. Returns content.
        """
        logger.info(f"[{session_id}] ArchitectAgent: generating SDD (attempt {attempt})")

        conflict_context = self._format_conflicts(previous_conflicts or [])
        system_prompt = self._sdd_prompt_template.replace("{conflict_context}", conflict_context)

        content = await self._call_llm(
            system=system_prompt,
            user_message=prd_content,
            max_tokens=self.MAX_TOKENS_SDD,
            session_id=session_id,
        )

        self.store.write(session_id, "sdd.md", content)
        logger.info(f"[{session_id}] ArchitectAgent: SDD written ({len(content)} chars)")
        return content

    async def generate_api_spec(
        self,
        prd_content: str,
        sdd_content: str,
        session_id: str,
        attempt: int = 0,
    ) -> str:
        """
        Generate OpenAPI spec from PRD + SDD.
        Saves api_spec.yaml. Returns content.
        """
        logger.info(f"[{session_id}] ArchitectAgent: generating API spec (attempt {attempt})")

        system_prompt = self._api_prompt_template.replace(
            "{prd_content}", prd_content
        ).replace(
            "{sdd_content}", sdd_content
        )

        # For the API spec, the combined PRD+SDD context is in the system prompt.
        # User message is a simple instruction to proceed.
        content = await self._call_llm(
            system=system_prompt,
            user_message="Generate the OpenAPI specification now.",
            max_tokens=self.MAX_TOKENS_API,
            session_id=session_id,
        )

        # Strip any accidental markdown code fences
        content = self._strip_yaml_fences(content)

        self.store.write(session_id, "api_spec.yaml", content)
        logger.info(f"[{session_id}] ArchitectAgent: API spec written ({len(content)} chars)")
        return content

    def _format_conflicts(self, conflicts: list[Conflict]) -> str:
        if not conflicts:
            return "(none — this is the first attempt)"
        lines = ["The following conflicts were found in the previous attempt. Fix them in this version:\n"]
        for i, c in enumerate(conflicts, 1):
            lines.append(f"{i}. [{c.severity.upper()}] {c.type.value}")
            lines.append(f"   Description: {c.description}")
            lines.append(f"   PRD says: {c.prd_reference}")
            lines.append(f"   SDD says: {c.sdd_reference}")
            lines.append("")
        return "\n".join(lines)

    @staticmethod
    def _strip_yaml_fences(content: str) -> str:
        """Remove ```yaml ... ``` wrapping if the LLM included it."""
        content = content.strip()
        if content.startswith("```yaml"):
            content = content[7:]
        elif content.startswith("```"):
            content = content[3:]
        if content.endswith("```"):
            content = content[:-3]
        return content.strip()

    async def _call_llm(
        self,
        system: str,
        user_message: str,
        max_tokens: int,
        session_id: str,
    ) -> str:
        payload = {
            "model": self.MODEL,
            "max_tokens": max_tokens,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user_message},
            ],
        }

        async with httpx.AsyncClient(timeout=self.TIMEOUT) as client:
            try:
                response = await client.post(
                    f"{self.llm_gateway_url}/v1/chat/completions",
                    json=payload,
                )
                response.raise_for_status()
            except httpx.HTTPStatusError as e:
                logger.error(
                    f"[{session_id}] ArchitectAgent LLM error {e.response.status_code}: {e.response.text[:500]}"
                )
                raise

        data = response.json()
        content = data["choices"][0]["message"]["content"]

        if not content or len(content.strip()) < 100:
            raise ValueError(
                f"[{session_id}] ArchitectAgent received suspiciously short LLM response ({len(content)} chars)"
            )

        return content.strip()
