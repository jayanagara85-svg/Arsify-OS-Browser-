import uuid
import logging
from datetime import datetime, timezone
from typing import Any, Optional

from ..models.schemas import PipelineStatus, SessionState
from ..storage.file_store import FileStore

logger = logging.getLogger(__name__)


class SessionManager:
    """
    Owns the session lifecycle. Creates, reads, updates session.json.
    All state transitions go through this class.
    """

    def __init__(self, file_store: FileStore):
        self.store = file_store

    def create(self, brief: str) -> str:
        """Create a new session. Returns session_id."""
        session_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()
        data = {
            "session_id": session_id,
            "brief": brief,
            "status": PipelineStatus.QUEUED.value,
            "step": 0,
            "attempt": 0,
            "created_at": now,
            "updated_at": now,
            "completed_at": None,
            "consistency_score": None,
            "consistency_result": None,
            "error": None,
        }
        self.store.write_session(session_id, data)
        logger.info(f"[{session_id}] Session created")
        return session_id

    def update(self, session_id: str, status: PipelineStatus, **kwargs: Any) -> None:
        """Update session status and any additional fields."""
        data = self.store.read_session(session_id)
        data["status"] = status.value
        data.update(kwargs)

        if status == PipelineStatus.COMPLETE:
            data["completed_at"] = datetime.now(timezone.utc).isoformat()

        self.store.write_session(session_id, data)
        logger.info(f"[{session_id}] Status → {status.value} (step={kwargs.get('step', data.get('step'))})")

    def fail(self, session_id: str, error: str) -> None:
        """Mark session as failed with error message."""
        data = self.store.read_session(session_id)
        data["status"] = PipelineStatus.FAILED.value
        data["error"] = error
        data["completed_at"] = datetime.now(timezone.utc).isoformat()
        self.store.write_session(session_id, data)
        logger.error(f"[{session_id}] Pipeline failed: {error}")

    def get(self, session_id: str) -> Optional[SessionState]:
        """Return session state. None if session does not exist."""
        if not self.store.session_exists(session_id):
            return None
        data = self.store.read_session(session_id)
        return SessionState(**data)
