"""
UPSHALTER API HUB v2 — FastAPI Gateway
Hostinger frontend ↔ Sumopod backend services

v2 changes:
  - Removed: /api/agents (OpenHands removed)
  - Removed: /api/workflows (n8n removed)
  - Added:   /api/pipeline/* (new pipeline_engine)
  - Kept:    /api/models/* (LiteLLM passthrough)
"""

import os
import logging

import httpx
from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
PIPELINE_ENGINE_URL = os.environ.get("PIPELINE_ENGINE_URL", "http://pipeline_engine:8001")
LLM_GATEWAY_URL = os.environ.get("LLM_GATEWAY_URL", "http://or_gateway:4000")
API_SECRET = os.environ["API_SECRET"]

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Upshalter API Hub v2",
    description="Gateway: Hostinger frontend → Sumopod backend services",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://workspace.upshalter.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Auth ──────────────────────────────────────────────────────────────────────
async def verify_token(x_api_key: str = Header(...)):
    if x_api_key != API_SECRET:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return x_api_key


# ── Health ────────────────────────────────────────────────────────────────────
@app.get("/health")
async def health():
    return {"status": "ok", "service": "api_hub", "version": "2.0.0"}


# ── Pipeline endpoints ─────────────────────────────────────────────────────────
@app.post("/api/pipeline/run", dependencies=[Depends(verify_token)])
async def run_pipeline(payload: dict):
    """
    Start a document generation pipeline.
    Body: {"brief": "Your product idea here"}
    Returns: {"session_id": "uuid", "status": "queued"}
    """
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            r = await client.post(f"{PIPELINE_ENGINE_URL}/pipeline/run", json=payload)
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            logger.error(f"Pipeline run error: {e.response.status_code} — {e.response.text}")
            raise HTTPException(status_code=e.response.status_code, detail=e.response.json())
        except httpx.RequestError as e:
            logger.error(f"Pipeline engine unreachable: {e}")
            raise HTTPException(status_code=503, detail="Pipeline engine unavailable")
    return r.json()


@app.get("/api/pipeline/status/{session_id}", dependencies=[Depends(verify_token)])
async def get_pipeline_status(session_id: str):
    """
    Get pipeline status and current step.
    Returns: SessionState object with status, step, attempt, timestamps.
    """
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            r = await client.get(f"{PIPELINE_ENGINE_URL}/pipeline/status/{session_id}")
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=e.response.json())
        except httpx.RequestError as e:
            raise HTTPException(status_code=503, detail="Pipeline engine unavailable")
    return r.json()


@app.get("/api/pipeline/output/{session_id}", dependencies=[Depends(verify_token)])
async def get_pipeline_output(session_id: str):
    """
    Get completed output bundle.
    Returns: {session_id, status, consistency_score, outputs: {prd, sdd, api_spec}}
    404 if pipeline not yet complete.
    """
    async with httpx.AsyncClient(timeout=15.0) as client:
        try:
            r = await client.get(f"{PIPELINE_ENGINE_URL}/pipeline/output/{session_id}")
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=e.response.json())
        except httpx.RequestError as e:
            raise HTTPException(status_code=503, detail="Pipeline engine unavailable")
    return r.json()


# ── Model passthrough (LiteLLM) ────────────────────────────────────────────────
@app.post("/api/models/chat", dependencies=[Depends(verify_token)])
async def chat_completion(payload: dict):
    """Direct LLM access for Paperclip UI chat features."""
    async with httpx.AsyncClient(timeout=120.0) as client:
        try:
            r = await client.post(f"{LLM_GATEWAY_URL}/v1/chat/completions", json=payload)
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=e.response.text)
    return r.json()


@app.get("/api/models/usage", dependencies=[Depends(verify_token)])
async def get_usage():
    """Token usage and cost from LiteLLM."""
    async with httpx.AsyncClient(timeout=10.0) as client:
        r = await client.get(f"{LLM_GATEWAY_URL}/spend/logs")
        return r.json()
