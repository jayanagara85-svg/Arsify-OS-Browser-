"""
Upshalter Orchestration — Structured Logger

Every pipeline step, every retry, every consistency score is a structured
log record. This makes debugging a failed run trivial: filter by session_id,
read the records in order, see exactly what happened at every step.

Log record format (JSON lines):
{
  "ts":          "2025-01-01T10:02:14Z",
  "session_id":  "3f2a1b...",
  "level":       "INFO",
  "component":   "Marshal",
  "event":       "consistency_checked",
  "step":        5,
  "attempt":     1,
  "score":       85,
  "conflicts":   2,
  "message":     "1 critical conflict → retry scheduled"
}

Usage:
    log = PipelineLogger(session_id="abc123")
    log.step("PRD generation started", component="ProductAgent", step=1)
    log.retry("Entity mismatch: Member vs User", attempt=1, conflict_count=1)
    log.score(85, attempt=1, conflicts=[...])
    log.complete(score=100)
    log.fail("LLM timeout after 120s", component="ArchitectAgent")
"""
from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, timezone
from typing import Any, Optional


# ── Base Python logger (writes to stdout in production) ───────────────────────

_root = logging.getLogger("upshalter.pipeline")
if not _root.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("%(message)s"))
    _root.addHandler(handler)
    _root.setLevel(logging.DEBUG)


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _emit(record: dict[str, Any], level: str = "INFO") -> None:
    """Write one JSON line to stdout."""
    record["ts"] = _now()
    record["level"] = level
    _root.info(json.dumps(record, default=str))


# ── Per-Session Logger ────────────────────────────────────────────────────────

class PipelineLogger:
    """
    Structured logger scoped to one pipeline session.
    Every method emits one JSON log record.
    All records carry session_id for easy filtering.

    Use this class everywhere in the pipeline instead of logging.getLogger().
    The output is machine-readable: grep by session_id, pipe to jq.
    """

    STEPS = {
        0: "initialised",
        1: "prd_generation",
        2: "prd_validation_entity_extraction",
        3: "sdd_generation",
        4: "api_spec_generation",
        5: "consistency_check",
        6: "complete",
    }

    def __init__(self, session_id: str):
        self.session_id = session_id
        self._step = 0
        self._attempt = 0

    def _base(self, component: str, event: str, step: Optional[int] = None,
              attempt: Optional[int] = None) -> dict:
        return {
            "session_id": self.session_id,
            "component":  component,
            "event":      event,
            "step":       step if step is not None else self._step,
            "step_name":  self.STEPS.get(step if step is not None else self._step, "unknown"),
            "attempt":    attempt if attempt is not None else self._attempt,
        }

    # ── Core step events ──────────────────────────────────────────────────────

    def step(self, message: str, component: str, step: int,
             attempt: int = 0, **extra: Any) -> None:
        """A pipeline step has started."""
        self._step = step
        self._attempt = attempt
        record = self._base(component, "step_started", step, attempt)
        record["message"] = message
        record.update(extra)
        _emit(record)

    def step_complete(self, message: str, component: str,
                      chars_written: Optional[int] = None, **extra: Any) -> None:
        """A pipeline step has completed successfully."""
        record = self._base(component, "step_complete")
        record["message"] = message
        if chars_written is not None:
            record["chars_written"] = chars_written
        record.update(extra)
        _emit(record)

    # ── Validation events ──────────────────────────────────────────────────────

    def validation(self, passed: bool, component: str,
                   missing: Optional[list] = None, warnings: Optional[list] = None) -> None:
        record = self._base(component, "validation_result")
        record["passed"] = passed
        record["missing_sections"] = missing or []
        record["warning_count"] = len(warnings or [])
        if warnings:
            record["warnings"] = warnings
        _emit(record, level="INFO" if passed else "WARNING")

    # ── Entity extraction events ───────────────────────────────────────────────

    def entities(self, canonical_names: list[str], features: list[str],
                 method: str = "regex") -> None:
        record = self._base("EntityExtractor", "entities_extracted", step=2)
        record["canonical_names"] = canonical_names
        record["entity_count"] = len(canonical_names)
        record["feature_count"] = len(features)
        record["extraction_method"] = method
        record["has_manifest"] = len(canonical_names) > 0
        _emit(record)

    def entities_failed(self, error: str) -> None:
        record = self._base("EntityExtractor", "entities_extraction_failed", step=2)
        record["error"] = error
        record["message"] = "Continuing without entity constraints"
        _emit(record, level="WARNING")

    # ── Consistency events ─────────────────────────────────────────────────────

    def score(self, score: int, attempt: int,
              conflicts: list, consistent: bool, summary: str) -> None:
        """Consistency check result."""
        critical = [c for c in conflicts if c.get("severity") == "critical"]
        warnings = [c for c in conflicts if c.get("severity") == "warning"]

        record = self._base("ConsistencyEngine", "consistency_checked", step=5, attempt=attempt)
        record["score"] = score
        record["consistent"] = consistent
        record["critical_count"] = len(critical)
        record["warning_count"] = len(warnings)
        record["conflicts"] = [
            {"type": c.get("type"), "severity": c.get("severity"), "desc": c.get("description", "")[:80]}
            for c in conflicts
        ]
        record["summary"] = summary[:120]
        _emit(record, level="INFO" if consistent else "WARNING")

    # ── Retry events ──────────────────────────────────────────────────────────

    def retry(self, reason: str, attempt: int,
              conflict_count: int, conflict_types: Optional[list] = None) -> None:
        """Marshal has decided to retry the Architect Agent."""
        record = self._base("Marshal", "retry_scheduled", step=5, attempt=attempt)
        record["reason"] = reason
        record["conflict_count"] = conflict_count
        record["conflict_types"] = conflict_types or []
        record["next_attempt"] = attempt + 1
        record["message"] = f"Retry {attempt + 1} scheduled — {conflict_count} critical conflict(s)"
        _emit(record, level="WARNING")

    def max_retries(self, score: int, conflicts: int) -> None:
        """Max retries reached — delivering output as-is."""
        record = self._base("Marshal", "max_retries_exceeded", step=5)
        record["score"] = score
        record["unresolved_conflicts"] = conflicts
        record["message"] = f"Max retries reached. Delivering with score={score}."
        _emit(record, level="WARNING")

    # ── Error events ──────────────────────────────────────────────────────────

    def error(self, message: str, component: str, error: Exception,
              recoverable: bool = False) -> None:
        record = self._base(component, "error")
        record["message"] = message
        record["error_type"] = type(error).__name__
        record["error_detail"] = str(error)[:200]
        record["recoverable"] = recoverable
        _emit(record, level="ERROR")

    def fail(self, message: str, component: str, error: Optional[Exception] = None) -> None:
        """Pipeline has failed permanently."""
        record = self._base(component, "pipeline_failed")
        record["message"] = message
        if error:
            record["error_type"] = type(error).__name__
            record["error_detail"] = str(error)[:200]
        _emit(record, level="ERROR")

    # ── Completion ────────────────────────────────────────────────────────────

    def complete(self, score: int, total_attempts: int,
                 elapsed_seconds: Optional[float] = None) -> None:
        record = self._base("Marshal", "pipeline_complete", step=6)
        record["final_score"] = score
        record["total_attempts"] = total_attempts
        if elapsed_seconds is not None:
            record["elapsed_seconds"] = round(elapsed_seconds, 1)
        record["message"] = f"Pipeline complete. score={score}, attempts={total_attempts}"
        _emit(record)

    # ── Event bus trace ───────────────────────────────────────────────────────

    def event_emitted(self, event_name: str, payload_keys: list[str]) -> None:
        record = self._base("EventBus", "event_emitted")
        record["event"] = event_name
        record["payload_keys"] = payload_keys
        _emit(record, level="DEBUG")
