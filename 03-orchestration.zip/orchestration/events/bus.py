"""
Upshalter Orchestration — Event Bus

Every state transition in the pipeline emits a typed event.
Marshal is the only component that subscribes to events that require decisions.
Agents emit completion events. Planner emits request events.

Event flow:
  Planner         → emits: PipelineRequested
  Marshal         → subscribes: PipelineRequested
  Marshal         → emits: PrdRequested
  ProductAgent    → subscribes: PrdRequested
  ProductAgent    → emits: PrdGenerated
  Marshal         → subscribes: PrdGenerated
  Marshal         → emits: ArchitectRequested (with EntityManifest)
  ArchitectAgent  → subscribes: ArchitectRequested
  ArchitectAgent  → emits: DocsGenerated
  Marshal         → subscribes: DocsGenerated
  Marshal         → emits: ConsistencyPassed | RetryRequested | OutputReady
  Planner         → subscribes: OutputReady

This makes every step traceable: log the event, and you know exactly
which component triggered which transition and when.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Coroutine
from uuid import uuid4

logger = logging.getLogger(__name__)


# ── Event Names ───────────────────────────────────────────────────────────────

class EventName(str, Enum):
    # Planner → Marshal
    PIPELINE_REQUESTED   = "pipeline.requested"

    # Marshal → ProductAgent
    PRD_REQUESTED        = "prd.requested"

    # ProductAgent → Marshal
    PRD_GENERATED        = "prd.generated"

    # Marshal internal (validation + extraction complete)
    ENTITIES_EXTRACTED   = "entities.extracted"

    # Marshal → ArchitectAgent
    ARCHITECT_REQUESTED  = "architect.requested"

    # ArchitectAgent → Marshal
    DOCS_GENERATED       = "docs.generated"

    # Marshal → ConsistencyEngine
    CONSISTENCY_REQUESTED = "consistency.requested"

    # ConsistencyEngine → Marshal
    CONSISTENCY_CHECKED  = "consistency.checked"

    # Marshal decisions
    RETRY_REQUESTED      = "retry.requested"
    OUTPUT_READY         = "output.ready"

    # Error events (Marshal → Planner)
    PIPELINE_FAILED      = "pipeline.failed"
    MAX_RETRIES_EXCEEDED = "max_retries.exceeded"


# ── Event Payloads ────────────────────────────────────────────────────────────

@dataclass
class Event:
    name: EventName
    session_id: str
    payload: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid4())[:8])
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    attempt: int = 0

    def __repr__(self) -> str:
        return f"Event({self.name.value}, session={self.session_id[:8]}, attempt={self.attempt})"


# ── Handler Type ──────────────────────────────────────────────────────────────

Handler = Callable[[Event], Coroutine[Any, Any, None]]


# ── Event Bus ─────────────────────────────────────────────────────────────────

class EventBus:
    """
    Async event bus. In-process only (no Redis, no Kafka).
    Sufficient for a single VPS with sequential pipeline execution.

    Handlers are async coroutines registered per EventName.
    When an event is emitted, all registered handlers are awaited in order.

    Only Marshal registers handlers for decision events.
    Agents register handlers for their trigger events only.
    The Planner registers no handlers — it only emits.
    """

    def __init__(self):
        self._handlers: dict[EventName, list[Handler]] = {}
        self._history: list[Event] = []

    def subscribe(self, event_name: EventName, handler: Handler) -> None:
        """Register an async handler for an event. Called at startup."""
        if event_name not in self._handlers:
            self._handlers[event_name] = []
        self._handlers[event_name].append(handler)
        logger.debug(f"EventBus: {handler.__qualname__} subscribed to {event_name.value}")

    async def emit(self, event: Event) -> None:
        """
        Emit an event. Awaits all registered handlers in order.
        Records event in history for the session log.
        Exceptions in handlers are caught, logged, and re-raised.
        """
        self._history.append(event)
        logger.debug(f"EventBus: emit {event}")

        handlers = self._handlers.get(event.name, [])
        if not handlers:
            logger.warning(f"EventBus: no handlers for {event.name.value}")
            return

        for handler in handlers:
            try:
                await handler(event)
            except Exception as e:
                logger.error(
                    f"EventBus: handler {handler.__qualname__} failed "
                    f"for {event.name.value} [{event.session_id[:8]}]: {e}",
                    exc_info=True,
                )
                raise

    def session_history(self, session_id: str) -> list[Event]:
        """Return all events for a session in emission order."""
        return [e for e in self._history if e.session_id == session_id]

    def clear_session(self, session_id: str) -> None:
        """Remove session events from history (cleanup after output delivered)."""
        self._history = [e for e in self._history if e.session_id != session_id]


# ── Singleton ─────────────────────────────────────────────────────────────────
# One bus for the whole process. All components share this instance.

bus = EventBus()
