"""
pipeline_engine/main.py — Orchestrated version (Phase 4)

Drop-in replacement for the Phase 3.5 main.py.
One change: Marshal → Orchestrator.
Everything visible to the HTTP client is identical.

The Orchestrator is Marshal + event bus + structured logging.
Same session_id, same endpoints, same response schemas.
"""
import logging
import os
from contextlib import asynccontextmanager

from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .core.orchestrator import Orchestrator
from .models.schemas import (
    OutputBundle,
    PipelineRequest,
    PipelineRunResponse,
    PipelineStatus,
    SessionState,
)
from .storage.file_store import FileStore

logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",   # PipelineLogger emits JSON; don't double-format
)
logger = logging.getLogger(__name__)

LLM_GATEWAY_URL = os.environ.get("PIPELINE_LLM_GATEWAY", "http://or_gateway:4000")
STORAGE_PATH = os.environ.get("PIPELINE_STORAGE_PATH", "/pipeline_outputs")

orchestrator: Orchestrator | None = None
file_store: FileStore | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global orchestrator, file_store
    logger.info(f"pipeline_engine starting — gateway={LLM_GATEWAY_URL}")

    orchestrator = Orchestrator(
        llm_gateway_url=LLM_GATEWAY_URL,
        storage_base=STORAGE_PATH,
    )
    file_store = FileStore(base_path=STORAGE_PATH)

    logger.info("Orchestrator active — Marshal Engine v1 event-driven mode")
    yield
    logger.info("pipeline_engine shutting down")


app = FastAPI(
    title="Upshalter Pipeline Engine",
    description="Marshal Engine v1 — Event-Driven Orchestration",
    version="4.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


async def _run(session_id: str, brief: str) -> None:
    try:
        await orchestrator.run(session_id=session_id, brief=brief)
    except Exception:
        pass  # Logged and stored by Orchestrator._on_pipeline_failed


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "pipeline_engine",
        "version": "4.0.0",
        "mode": "event_driven",
        "marshal": "v1_orchestrated",
    }


@app.post("/pipeline/run", response_model=PipelineRunResponse, status_code=202)
async def run_pipeline(request: PipelineRequest, background_tasks: BackgroundTasks):
    session_id = orchestrator.create_session(request.brief)
    background_tasks.add_task(_run, session_id, request.brief)
    return PipelineRunResponse(session_id=session_id)


@app.get("/pipeline/status/{session_id}", response_model=SessionState)
async def get_status(session_id: str):
    state = orchestrator.session_mgr.get(session_id)
    if state is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    return state


@app.get("/pipeline/output/{session_id}", response_model=OutputBundle)
async def get_output(session_id: str):
    state = orchestrator.session_mgr.get(session_id)
    if state is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")

    if state.status == PipelineStatus.FAILED:
        raise HTTPException(status_code=500, detail={"error": state.error})

    if state.status != PipelineStatus.COMPLETE:
        raise HTTPException(
            status_code=404,
            detail={"message": "Pipeline not complete", "status": state.status},
        )

    try:
        outputs = {
            "prd":      file_store.read(session_id, "prd.md"),
            "sdd":      file_store.read(session_id, "sdd.md"),
            "api_spec": file_store.read(session_id, "api_spec.yaml"),
        }
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=f"Output file missing: {e}")

    return OutputBundle(
        session_id=session_id,
        status=state.status,
        consistency_score=state.consistency_score,
        consistency_result=state.consistency_result,
        outputs=outputs,
    )


@app.get("/pipeline/events/{session_id}")
async def get_events(session_id: str):
    """
    Return the full event history for a session.
    Useful for debugging: every step, every emit, in order.
    """
    from .events.bus import bus
    events = bus.session_history(session_id)
    return {
        "session_id": session_id,
        "event_count": len(events),
        "events": [
            {
                "event_id":   e.event_id,
                "name":       e.name.value,
                "attempt":    e.attempt,
                "timestamp":  e.timestamp,
                "payload_keys": list(e.payload.keys()),
            }
            for e in events
        ],
    }
