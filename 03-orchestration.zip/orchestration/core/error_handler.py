"""
Upshalter Orchestration — Error Handler

Classifies every exception the pipeline can encounter.
Marshal calls this instead of writing ad-hoc try/except everywhere.

Error classes:
  RETRYABLE   — transient failure, try again (LLM 429, timeout, empty response)
  FATAL       — pipeline cannot continue (brief too short, filesystem full)
  DEGRADED    — pipeline continues but with reduced quality (no entity manifest)

Decision table:
  RETRYABLE + retries_remaining  → re-run the failed step
  RETRYABLE + no retries_left    → FATAL (exhausted)
  FATAL                          → mark session failed, return error
  DEGRADED                       → log warning, continue with fallback

Usage in Marshal:
    result = error_handler.classify(e, context="ProductAgent LLM call")
    if result.action == ErrorAction.RETRY:
        continue  # retry loop handles it
    elif result.action == ErrorAction.DEGRADE:
        manifest = EntityManifest()  # empty fallback
    else:
        raise  # fatal — bubble up to session.fail()
"""
from __future__ import annotations

import httpx
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class ErrorAction(str, Enum):
    RETRY    = "retry"
    DEGRADE  = "degrade"
    FATAL    = "fatal"


class ErrorCategory(str, Enum):
    LLM_RATE_LIMIT    = "llm_rate_limit"
    LLM_TIMEOUT       = "llm_timeout"
    LLM_EMPTY         = "llm_empty_response"
    LLM_UPSTREAM      = "llm_upstream_error"
    VALIDATION_FAIL   = "validation_failed"
    PARSE_FAIL        = "parse_failed"
    FILESYSTEM        = "filesystem_error"
    ENTITY_EXTRACT    = "entity_extraction_failed"
    UNKNOWN           = "unknown"


@dataclass
class ErrorResult:
    action:   ErrorAction
    category: ErrorCategory
    message:  str
    retryable: bool
    suggestion: Optional[str] = None


class ErrorHandler:
    """
    Classifies exceptions into actionable decisions.

    Marshal calls classify() in every except block.
    The returned ErrorResult tells Marshal what to do next.
    Agents never call this — they let exceptions propagate to Marshal.
    """

    # HTTP status codes that are transient (safe to retry)
    RETRYABLE_HTTP = {429, 500, 502, 503, 504}

    def classify(self, error: Exception, context: str = "") -> ErrorResult:
        """
        Classify an exception. Returns an ErrorResult with action.

        context: description of where the error occurred (for logging).
        """
        # ── LLM gateway errors (httpx) ────────────────────────────────────
        if isinstance(error, httpx.HTTPStatusError):
            status = error.response.status_code

            if status == 429:
                return ErrorResult(
                    action=ErrorAction.RETRY,
                    category=ErrorCategory.LLM_RATE_LIMIT,
                    message=f"[{context}] Rate limit hit (429). Will retry.",
                    retryable=True,
                    suggestion="or_gateway should handle backoff — check LiteLLM retry config",
                )
            if status in self.RETRYABLE_HTTP:
                return ErrorResult(
                    action=ErrorAction.RETRY,
                    category=ErrorCategory.LLM_UPSTREAM,
                    message=f"[{context}] Upstream error ({status}). Will retry.",
                    retryable=True,
                )
            # 4xx non-rate-limit = bad request = fatal
            return ErrorResult(
                action=ErrorAction.FATAL,
                category=ErrorCategory.LLM_UPSTREAM,
                message=f"[{context}] Non-retryable HTTP {status}: {error.response.text[:200]}",
                retryable=False,
                suggestion="Check LLM gateway config and API key",
            )

        if isinstance(error, httpx.TimeoutException):
            return ErrorResult(
                action=ErrorAction.RETRY,
                category=ErrorCategory.LLM_TIMEOUT,
                message=f"[{context}] LLM call timed out. Will retry.",
                retryable=True,
                suggestion="Increase PIPELINE_TIMEOUT_SECONDS or switch to faster model tier",
            )

        if isinstance(error, httpx.RequestError):
            return ErrorResult(
                action=ErrorAction.RETRY,
                category=ErrorCategory.LLM_UPSTREAM,
                message=f"[{context}] Network error reaching LLM gateway: {error}",
                retryable=True,
                suggestion="Check or_gateway container health",
            )

        # ── Empty / short LLM responses ───────────────────────────────────
        if isinstance(error, ValueError) and "short" in str(error).lower():
            return ErrorResult(
                action=ErrorAction.RETRY,
                category=ErrorCategory.LLM_EMPTY,
                message=f"[{context}] LLM returned suspiciously short content. Will retry.",
                retryable=True,
            )

        # ── JSON parse failures (consistency engine) ──────────────────────
        if isinstance(error, (ValueError, KeyError)) and context == "ConsistencyEngine":
            return ErrorResult(
                action=ErrorAction.DEGRADE,
                category=ErrorCategory.PARSE_FAIL,
                message=f"[{context}] Failed to parse consistency JSON. Continuing with score=50.",
                retryable=False,
                suggestion="Consistency check accepted with assumed score. Manual review recommended.",
            )

        # ── Entity extraction failures ─────────────────────────────────────
        if context in ("EntityExtractor", "regex_extract"):
            return ErrorResult(
                action=ErrorAction.DEGRADE,
                category=ErrorCategory.ENTITY_EXTRACT,
                message=f"[{context}] Entity extraction failed. Continuing without manifest.",
                retryable=False,
                suggestion="PRD may lack a Glossary section. Review prompt output.",
            )

        # ── Filesystem errors ──────────────────────────────────────────────
        if isinstance(error, (OSError, IOError, FileNotFoundError)):
            return ErrorResult(
                action=ErrorAction.FATAL,
                category=ErrorCategory.FILESYSTEM,
                message=f"[{context}] Filesystem error: {error}",
                retryable=False,
                suggestion="Check /pipeline_outputs volume mount on Sumopod",
            )

        # ── PRD/SDD validation failures ───────────────────────────────────
        if isinstance(error, ValueError) and "validation" in str(error).lower():
            return ErrorResult(
                action=ErrorAction.RETRY,
                category=ErrorCategory.VALIDATION_FAIL,
                message=f"[{context}] Document validation failed. Will regenerate.",
                retryable=True,
            )

        # ── Fallback: unknown ──────────────────────────────────────────────
        return ErrorResult(
            action=ErrorAction.FATAL,
            category=ErrorCategory.UNKNOWN,
            message=f"[{context}] Unclassified error: {type(error).__name__}: {error}",
            retryable=False,
        )

    def is_retryable(self, error: Exception, context: str = "") -> bool:
        return self.classify(error, context).action == ErrorAction.RETRY

    def is_degraded(self, error: Exception, context: str = "") -> bool:
        return self.classify(error, context).action == ErrorAction.DEGRADE


# Singleton — shared by Marshal and all components
error_handler = ErrorHandler()
