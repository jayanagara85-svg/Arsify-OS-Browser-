"""
Upshalter Orchestration — Orchestrator

Wires together:
  - EventBus (event routing)
  - MarshalV1 (decision engine)
  - ProductAgent (PRD generation)
  - ArchitectAgentV1 (SDD + API generation)
  - ConsistencyEngineV1 (validation)
  - ErrorHandler (error classification)
  - PipelineLogger (structured logging)

This is the ONLY file that imports all components.
main.py imports only Orchestrator. Everything else is internal.

Startup sequence:
  1. Orchestrator.__init__() creates all components
  2. _register_handlers() wires components to events
  3. FastAPI lifespan calls orchestrator.start()
  4. HTTP requests call orchestrator.run(session_id, brief)

Event → Handler mapping (the wiring):
  PIPELINE_REQUESTED   → _on_pipeline_requested  (Orchestrator)
  PRD_REQUESTED        → _on_prd_requested        (ProductAgent wrapper)
  PRD_GENERATED        → _on_prd_generated        (Marshal)
  ARCHITECT_REQUESTED  → _on_architect_requested  (ArchitectAgent wrapper)
  DOCS_GENERATED       → _on_docs_generated       (Marshal)
  CONSISTENCY_CHECKED  → _on_consistency_checked  (Marshal decision)
  RETRY_REQUESTED      → _on_retry_requested      (ArchitectAgent wrapper)
  OUTPUT_READY         → _on_output_ready         (session finaliser)
  PIPELINE_FAILED      → _on_pipeline_failed      (session finaliser)
"""
from __future__ import annotations

import asyncio
import time
import logging
from typing import Optional

from ..events.bus import EventBus, Event, EventName, bus as default_bus
from ..logging.structured_logger import PipelineLogger
from .error_handler import ErrorHandler, ErrorAction, error_handler as default_handler

# Pipeline components (imported here only)
from ..models.v1_schemas_locked import ContextBundle, EntityManifest
from ..models.schemas import PipelineStatus, ConsistencyResult
from ..storage.file_store import FileStore
from ..core.session import SessionManager
from ..core.product_agent import ProductAgent
from ..core.architect_agent_v1 import ArchitectAgentV1
from ..core.consistency_engine_v1 import ConsistencyEngineV1
from ..core.entity_extractor import EntityExtractor
from ..core.prd_validator import PrdValidator

logger = logging.getLogger(__name__)

MAX_RETRIES = 2
PRD_MAX_RETRIES = 1
LLM_STEP_MAX_RETRIES = 2  # for transient LLM errors within a single step


class Orchestrator:
    """
    Runnable orchestration layer.

    Responsibilities:
    - Instantiate all components (once, at startup)
    - Wire event handlers (subscribe all components to their events)
    - Run pipeline sessions via event flow
    - Delegate all decisions to Marshal (internal methods prefixed _marshal_*)
    - Log every step, retry, score, and error

    The Orchestrator is Marshal in operational form.
    It IS the Marshal Engine v1 — implemented as event-driven rather than
    a sequential awaited call chain. The logic is identical; the mechanism
    is event-based for observability.
    """

    def __init__(
        self,
        llm_gateway_url: str,
        storage_base: str = "/pipeline_outputs",
        bus: Optional[EventBus] = None,
        error_handler_: Optional[ErrorHandler] = None,
    ):
        self.llm_url = llm_gateway_url
        self.bus = bus or default_bus
        self.errors = error_handler_ or default_handler

        # Storage + session
        self.file_store = FileStore(storage_base)
        self.session_mgr = SessionManager(self.file_store)

        # Components — Orchestrator creates and owns all of them
        self.product_agent = ProductAgent(llm_gateway_url, self.file_store)
        self.architect = ArchitectAgentV1(llm_gateway_url, self.file_store)
        self.consistency = ConsistencyEngineV1(llm_gateway_url)
        self.extractor = EntityExtractor(llm_gateway_url)
        self.validator = PrdValidator()

        # Per-session state (in-memory, keyed by session_id)
        # Holds ContextBundle + attempt count during pipeline execution
        self._sessions: dict[str, dict] = {}

        # Register event handlers
        self._register_handlers()

    def _register_handlers(self) -> None:
        """Wire every event to its handler. Called once at startup."""
        self.bus.subscribe(EventName.PIPELINE_REQUESTED,  self._on_pipeline_requested)
        self.bus.subscribe(EventName.PRD_REQUESTED,       self._on_prd_requested)
        self.bus.subscribe(EventName.PRD_GENERATED,       self._on_prd_generated)
        self.bus.subscribe(EventName.ARCHITECT_REQUESTED, self._on_architect_requested)
        self.bus.subscribe(EventName.DOCS_GENERATED,      self._on_docs_generated)
        self.bus.subscribe(EventName.CONSISTENCY_CHECKED, self._on_consistency_checked)
        self.bus.subscribe(EventName.RETRY_REQUESTED,     self._on_retry_requested)
        self.bus.subscribe(EventName.OUTPUT_READY,        self._on_output_ready)
        self.bus.subscribe(EventName.PIPELINE_FAILED,     self._on_pipeline_failed)
        logger.info("Orchestrator: all event handlers registered")

    # ── Public API (called by Planner / main.py) ──────────────────────────────

    def create_session(self, brief: str) -> str:
        """Create session. Returns session_id. Planner calls this."""
        return self.session_mgr.create(brief)

    async def run(self, session_id: str, brief: str) -> None:
        """
        Entry point for background pipeline execution.
        Emits PIPELINE_REQUESTED. Everything else is event-driven.
        """
        log = PipelineLogger(session_id)
        self._sessions[session_id] = {
            "brief": brief,
            "log": log,
            "start_time": time.monotonic(),
            "attempt": 0,
            "context": None,
            "prior_conflicts": [],
        }

        log.step("Pipeline requested", component="Planner", step=0)

        await self.bus.emit(Event(
            name=EventName.PIPELINE_REQUESTED,
            session_id=session_id,
            payload={"brief": brief},
        ))

    # ── Event Handlers ────────────────────────────────────────────────────────

    async def _on_pipeline_requested(self, event: Event) -> None:
        """Planner → Marshal: validate brief, emit PRD_REQUESTED."""
        sid = event.session_id
        state = self._sessions[sid]
        log: PipelineLogger = state["log"]

        brief = event.payload["brief"]

        # Marshal: validate brief
        if len(brief.strip()) < 50:
            await self.bus.emit(Event(
                name=EventName.PIPELINE_FAILED,
                session_id=sid,
                payload={"error": "Brief too short (minimum 50 characters)"},
            ))
            return

        self.session_mgr.update(sid, PipelineStatus.GENERATING_PRD, step=1)
        log.step("Brief validated. Requesting PRD.", component="Marshal", step=1)

        await self.bus.emit(Event(
            name=EventName.PRD_REQUESTED,
            session_id=sid,
            payload={"brief": brief},
        ))

    async def _on_prd_requested(self, event: Event) -> None:
        """Marshal → ProductAgent: generate PRD."""
        sid = event.session_id
        state = self._sessions[sid]
        log: PipelineLogger = state["log"]

        for attempt in range(PRD_MAX_RETRIES + 1):
            try:
                prd = await self.product_agent.generate(state["brief"], sid)
                log.step_complete("PRD generated", component="ProductAgent",
                                  chars_written=len(prd))
                await self.bus.emit(Event(
                    name=EventName.PRD_GENERATED,
                    session_id=sid,
                    payload={"prd_content": prd},
                ))
                return
            except Exception as e:
                result = self.errors.classify(e, "ProductAgent")
                log.error("PRD generation error", "ProductAgent", e,
                          recoverable=result.action == ErrorAction.RETRY)
                if result.action == ErrorAction.RETRY and attempt < PRD_MAX_RETRIES:
                    await asyncio.sleep(3)
                    continue
                await self.bus.emit(Event(
                    name=EventName.PIPELINE_FAILED,
                    session_id=sid,
                    payload={"error": result.message},
                ))
                return

    async def _on_prd_generated(self, event: Event) -> None:
        """Marshal: validate PRD, extract entities, build ContextBundle, emit ARCHITECT_REQUESTED."""
        sid = event.session_id
        state = self._sessions[sid]
        log: PipelineLogger = state["log"]
        prd = event.payload["prd_content"]

        # Step 2a: Marshal validates PRD structure
        self.session_mgr.update(sid, PipelineStatus.GENERATING_PRD, step=2)
        log.step("Validating PRD structure", component="Marshal", step=2)

        validation = self.validator.validate(prd, sid)
        log.validation(
            passed=validation.valid,
            component="PrdValidator",
            missing=list(validation.missing_sections),
            warnings=list(validation.warnings),
        )

        # Step 2b: Marshal extracts entities
        try:
            manifest = await self.extractor.extract(prd, sid)
            log.entities(
                canonical_names=list(manifest.canonical_names),
                features=list(manifest.features),
                method="regex" if manifest.has_entities else "llm_fallback",
            )
        except Exception as e:
            result = self.errors.classify(e, "EntityExtractor")
            log.entities_failed(result.message)
            manifest = EntityManifest()  # empty fallback, pipeline continues

        # Build frozen ContextBundle
        context = ContextBundle(prd_content=prd, entity_manifest=manifest)
        state["context"] = context

        self.session_mgr.update(sid, PipelineStatus.GENERATING_SDD, step=3)
        log.step("Entity manifest built. Requesting SDD.", component="Marshal", step=3)

        await self.bus.emit(Event(
            name=EventName.ARCHITECT_REQUESTED,
            session_id=sid,
            attempt=state["attempt"],
            payload={"prior_conflicts": state["prior_conflicts"]},
        ))

    async def _on_architect_requested(self, event: Event) -> None:
        """Marshal → ArchitectAgent: generate SDD then API Spec."""
        sid = event.session_id
        state = self._sessions[sid]
        log: PipelineLogger = state["log"]
        context: ContextBundle = state["context"]
        attempt = event.attempt
        prior_conflicts = event.payload.get("prior_conflicts", [])

        # Generate SDD
        for llm_attempt in range(LLM_STEP_MAX_RETRIES + 1):
            try:
                sdd = await self.architect.generate_sdd(
                    context=context,
                    session_id=sid,
                    attempt=attempt,
                    prior_conflicts=prior_conflicts,
                )
                log.step_complete("SDD generated", component="ArchitectAgent",
                                  chars_written=len(sdd))
                break
            except Exception as e:
                result = self.errors.classify(e, "ArchitectAgent")
                log.error("SDD generation error", "ArchitectAgent", e,
                          recoverable=result.action == ErrorAction.RETRY)
                if result.action == ErrorAction.RETRY and llm_attempt < LLM_STEP_MAX_RETRIES:
                    await asyncio.sleep(5)
                    continue
                await self.bus.emit(Event(
                    name=EventName.PIPELINE_FAILED, session_id=sid,
                    payload={"error": result.message},
                ))
                return

        # Update context with SDD (Marshal creates new snapshot — context is frozen)
        context = context.model_copy(update={"sdd_content": sdd})
        state["context"] = context

        # Generate API Spec
        self.session_mgr.update(sid, PipelineStatus.GENERATING_API_SPEC, step=4,
                                 attempt=attempt)
        log.step("SDD done. Generating API spec.", component="Marshal",
                 step=4, attempt=attempt)

        for llm_attempt in range(LLM_STEP_MAX_RETRIES + 1):
            try:
                api = await self.architect.generate_api_spec(
                    context=context,
                    session_id=sid,
                    attempt=attempt,
                )
                log.step_complete("API spec generated", component="ArchitectAgent",
                                  chars_written=len(api))
                break
            except Exception as e:
                result = self.errors.classify(e, "ArchitectAgent")
                if result.action == ErrorAction.RETRY and llm_attempt < LLM_STEP_MAX_RETRIES:
                    await asyncio.sleep(5)
                    continue
                await self.bus.emit(Event(
                    name=EventName.PIPELINE_FAILED, session_id=sid,
                    payload={"error": result.message},
                ))
                return

        # Update context with API spec
        context = context.model_copy(update={"api_content": api})
        state["context"] = context

        await self.bus.emit(Event(
            name=EventName.DOCS_GENERATED,
            session_id=sid,
            attempt=attempt,
            payload={},
        ))

    async def _on_docs_generated(self, event: Event) -> None:
        """Marshal: request consistency check."""
        sid = event.session_id
        state = self._sessions[sid]
        log: PipelineLogger = state["log"]

        self.session_mgr.update(sid, PipelineStatus.VALIDATING_CONSISTENCY,
                                 step=5, attempt=event.attempt)
        log.step("Docs generated. Running consistency check.",
                 component="Marshal", step=5, attempt=event.attempt)

        context: ContextBundle = state["context"]
        try:
            result: ConsistencyResult = await self.consistency.validate(
                session_id=sid, context=context
            )
        except Exception as e:
            err = self.errors.classify(e, "ConsistencyEngine")
            log.error("Consistency check error", "ConsistencyEngine", e,
                      recoverable=err.action != ErrorAction.FATAL)
            # Degrade: treat as consistent with score 50
            result = ConsistencyResult(
                consistent=True, score=50, conflicts=[],
                summary="Consistency check failed. Score assumed 50."
            )

        log.score(
            score=result.score,
            attempt=event.attempt,
            conflicts=[c.model_dump() for c in result.conflicts],
            consistent=result.consistent,
            summary=result.summary,
        )

        await self.bus.emit(Event(
            name=EventName.CONSISTENCY_CHECKED,
            session_id=sid,
            attempt=event.attempt,
            payload={"result": result},
        ))

    async def _on_consistency_checked(self, event: Event) -> None:
        """
        Marshal decision point.
        Critical conflicts + retries remaining → RETRY_REQUESTED
        Otherwise → OUTPUT_READY
        """
        sid = event.session_id
        state = self._sessions[sid]
        log: PipelineLogger = state["log"]
        result: ConsistencyResult = event.payload["result"]
        attempt = event.attempt

        critical = [c for c in result.conflicts if c.severity == "critical"]

        if not critical or attempt >= MAX_RETRIES:
            # Accept output
            if critical:
                log.max_retries(score=result.score, conflicts=len(critical))
            await self.bus.emit(Event(
                name=EventName.OUTPUT_READY,
                session_id=sid,
                payload={"consistency_result": result},
            ))
        else:
            # Retry
            log.retry(
                reason="Critical entity or endpoint mismatch",
                attempt=attempt,
                conflict_count=len(critical),
                conflict_types=list({c.type for c in critical}),
            )
            state["attempt"] = attempt + 1
            state["prior_conflicts"] = [c.model_dump() for c in critical]

            await self.bus.emit(Event(
                name=EventName.RETRY_REQUESTED,
                session_id=sid,
                attempt=attempt + 1,
                payload={"prior_conflicts": state["prior_conflicts"]},
            ))

    async def _on_retry_requested(self, event: Event) -> None:
        """Marshal: route retry back to Architect Agent."""
        sid = event.session_id
        state = self._sessions[sid]
        log: PipelineLogger = state["log"]

        log.step(
            f"Retry {event.attempt} — regenerating SDD + API Spec with conflict context",
            component="Marshal", step=3, attempt=event.attempt
        )
        self.session_mgr.update(sid, PipelineStatus.GENERATING_SDD,
                                 step=3, attempt=event.attempt)

        await self.bus.emit(Event(
            name=EventName.ARCHITECT_REQUESTED,
            session_id=sid,
            attempt=event.attempt,
            payload={"prior_conflicts": event.payload["prior_conflicts"]},
        ))

    async def _on_output_ready(self, event: Event) -> None:
        """Final step: mark session complete, log summary."""
        sid = event.session_id
        state = self._sessions[sid]
        log: PipelineLogger = state["log"]
        result: ConsistencyResult = event.payload["consistency_result"]

        elapsed = time.monotonic() - state["start_time"]

        self.session_mgr.update(
            sid, PipelineStatus.COMPLETE, step=6,
            consistency_score=result.score,
            consistency_result=result.model_dump(),
        )
        log.complete(
            score=result.score,
            total_attempts=state["attempt"] + 1,
            elapsed_seconds=elapsed,
        )

        # Clean up in-memory session state
        self._sessions.pop(sid, None)

    async def _on_pipeline_failed(self, event: Event) -> None:
        """Error path: mark session failed, log error."""
        sid = event.session_id
        state = self._sessions.get(sid, {})
        log = state.get("log") or PipelineLogger(sid)

        error_msg = event.payload.get("error", "Unknown error")
        self.session_mgr.fail(sid, error_msg)
        log.fail(error_msg, component="Marshal")
        self._sessions.pop(sid, None)
