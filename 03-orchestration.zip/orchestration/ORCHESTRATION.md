# Upshalter — Orchestration System Reference

## What This Is

The event-driven orchestration layer for Marshal Engine v1.
Replaces the sequential `await` call chain in `marshal_v1.py` with a typed
event bus. The logic is identical. The mechanism produces a traceable audit
trail of every transition in the pipeline.

---

## Component Roles (Final)

| Component | Role | Decides | Emits events |
|-----------|------|---------|--------------|
| **Planner** (main.py) | Route HTTP, create session, launch task | Nothing | `PIPELINE_REQUESTED` |
| **Orchestrator** (Marshal) | Every decision in the pipeline | Yes — all decisions | All transition events |
| **ProductAgent** | Generate PRD from brief | Nothing | `PRD_GENERATED` |
| **ArchitectAgent** | Generate SDD + API from ContextBundle | Nothing | `DOCS_GENERATED` |
| **ConsistencyEngine** | Score and list conflicts | Nothing | `CONSISTENCY_CHECKED` |
| **EntityExtractor** | Build EntityManifest from PRD | Nothing | Returns manifest to Marshal |
| **PrdValidator** | Check PRD structure | Nothing | Returns result to Marshal |
| **ErrorHandler** | Classify exceptions | Nothing | Returns ErrorResult to Marshal |
| **EventBus** | Route events to handlers | Nothing | Infrastructure only |

---

## Event Flow

```
Planner emits:       PIPELINE_REQUESTED  {brief}
  ↓
Marshal handles:     validate brief
Marshal emits:       PRD_REQUESTED  {brief}
  ↓
ProductAgent handles: generate prd.md
ProductAgent emits:  PRD_GENERATED  {prd_content}
  ↓
Marshal handles:     validate PRD structure
                     extract EntityManifest
                     build frozen ContextBundle
Marshal emits:       ARCHITECT_REQUESTED  {prior_conflicts}
  ↓
ArchitectAgent handles: generate sdd.md + api_spec.yaml
ArchitectAgent emits:   DOCS_GENERATED
  ↓
Marshal handles:     request consistency check
                     run ConsistencyEngineV1
Marshal emits:       CONSISTENCY_CHECKED  {result}
  ↓
Marshal handles:     [DECISION]
                     if critical conflicts + retries remaining:
                       emit RETRY_REQUESTED → ARCHITECT_REQUESTED (loop)
                     else:
                       emit OUTPUT_READY
  ↓
Marshal handles:     mark session COMPLETE
                     log final score + elapsed time
```

---

## Error Handling Logic

```
Every LLM call is wrapped:
  try:
    result = await agent.generate(...)
  except Exception as e:
    classified = error_handler.classify(e, context="AgentName")

    if classified.action == RETRY and llm_attempt < LLM_STEP_MAX_RETRIES:
        await asyncio.sleep(backoff)
        continue
    elif classified.action == DEGRADE:
        use_fallback()
        continue pipeline
    else:  # FATAL
        emit PIPELINE_FAILED
        return
```

Error classification table:

| Exception | Category | Action |
|-----------|----------|--------|
| `HTTPStatusError 429` | LLM_RATE_LIMIT | RETRY |
| `HTTPStatusError 5xx` | LLM_UPSTREAM | RETRY |
| `HTTPStatusError 4xx` | LLM_UPSTREAM | FATAL |
| `TimeoutException` | LLM_TIMEOUT | RETRY |
| `RequestError` | LLM_UPSTREAM | RETRY |
| `ValueError` ("short") | LLM_EMPTY | RETRY |
| `ValueError/KeyError` in ConsistencyEngine | PARSE_FAIL | DEGRADE (score=50) |
| `EntityExtractor` any | ENTITY_EXTRACT | DEGRADE (empty manifest) |
| `OSError/IOError` | FILESYSTEM | FATAL |
| Unknown | UNKNOWN | FATAL |

---

## Structured Log Format

Every event writes one JSON line to stdout:

```json
{"ts": "2025-01-01T10:02:14Z", "level": "INFO",
 "session_id": "3f2a1b...", "component": "Marshal",
 "event": "retry_scheduled", "step": 5, "step_name": "consistency_check",
 "attempt": 1, "conflict_count": 2, "conflict_types": ["entity_mismatch"],
 "next_attempt": 2, "message": "Retry 2 scheduled — 2 critical conflict(s)"}
```

Filter all logs for one session:
```bash
docker logs upshalter_pipeline_engine | grep '"session_id": "3f2a1b"'
```

Filter only retry events:
```bash
docker logs upshalter_pipeline_engine | jq 'select(.event == "retry_scheduled")'
```

Show consistency scores across all sessions:
```bash
docker logs upshalter_pipeline_engine | jq 'select(.event == "consistency_checked") | {session_id, score, attempt, critical_count}'
```

---

## New Endpoint: `/pipeline/events/{session_id}`

Returns the full event history for a session (in-memory, cleared after completion):

```json
{
  "session_id": "3f2a1b...",
  "event_count": 12,
  "events": [
    {"event_id": "a1b2c3", "name": "pipeline.requested",  "attempt": 0, "timestamp": "..."},
    {"event_id": "d4e5f6", "name": "prd.requested",       "attempt": 0, "timestamp": "..."},
    {"event_id": "g7h8i9", "name": "prd.generated",       "attempt": 0, "timestamp": "..."},
    {"event_id": "j0k1l2", "name": "entities.extracted",  "attempt": 0, "timestamp": "..."},
    {"event_id": "m3n4o5", "name": "architect.requested", "attempt": 0, "timestamp": "..."},
    {"event_id": "p6q7r8", "name": "docs.generated",      "attempt": 0, "timestamp": "..."},
    {"event_id": "s9t0u1", "name": "consistency.checked", "attempt": 0, "timestamp": "..."},
    {"event_id": "v2w3x4", "name": "retry.requested",     "attempt": 1, "timestamp": "..."},
    {"event_id": "y5z6a7", "name": "architect.requested", "attempt": 1, "timestamp": "..."},
    {"event_id": "b8c9d0", "name": "docs.generated",      "attempt": 1, "timestamp": "..."},
    {"event_id": "e1f2g3", "name": "consistency.checked", "attempt": 1, "timestamp": "..."},
    {"event_id": "h4i5j6", "name": "output.ready",        "attempt": 1, "timestamp": "..."}
  ]
}
```

This is the full audit trail. 12 events for 1 retry run. Readable in seconds.

---

## Activation

Replace in `main.py`:
```python
# Before
from .core.marshal_v1 import MarshalV1
marshal = MarshalV1(...)

# After
from .core.orchestrator import Orchestrator
orchestrator = Orchestrator(...)
```

Change two method calls:
```python
# Before
session_id = marshal.create_session(brief)
background_tasks.add_task(marshal.run, session_id, brief)

# After
session_id = orchestrator.create_session(brief)
background_tasks.add_task(orchestrator.run, session_id, brief)
```

Use `main_orchestrated.py` directly — it already has these changes.
Copy it over `main.py` and rebuild the container.

---

## Files Introduced

```
events/
  bus.py                 — EventBus, Event, EventName (9 event types)

logging/
  structured_logger.py   — PipelineLogger with 12 log methods

core/
  orchestrator.py        — Full event-driven orchestration (9 handlers)
  error_handler.py       — ErrorHandler with 8 error categories

main_orchestrated.py     — Drop-in main.py with /pipeline/events endpoint
```
